package project2413;

public class TestClass {
	
	//Will try different packages
	protected String msg;
	
	public TestClass(String msg) {
		
		this.msg = msg;
	}
	
	public void test() {
		
		System.out.println(this.msg);
		
	}

}
