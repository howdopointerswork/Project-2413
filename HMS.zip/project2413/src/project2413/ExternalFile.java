package project2413;


public class ExternalFile{
	
	public static void main(String[] args) {
		
		TestClass tc = new TestClass("Testing");
		
		tc.test();
		
	}
}