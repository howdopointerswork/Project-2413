package project2413;


public class GastrointestinalTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	GastrointestinalTest(String date, String category, int id){
		
		super(date, category, id);
		
	}
	

	public void enterResults(String stoolSampleType, String analysis) {
		
		
		
	}
	
}