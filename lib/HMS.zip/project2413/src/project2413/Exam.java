package project2413;


public class Exam{
	
	private String date;
	
	private int id;
	
	private Exam[] results;
			
	
	
	
	
	Exam(String date, int id){
		
			this.date = date;
			
			this.id = id;
			
			
		
	}
	
	String getDate() {
		
		return this.date;
		
	}
	
	
	
	int getID() {
		
		return this.id;
	}
	
	
	public void enterResults() {
		
		
		
	}
	
	
	
}