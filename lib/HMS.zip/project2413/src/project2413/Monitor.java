package project2413;

import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.Collections;
import java.util.*;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.*;
//measure dates here
//compare earliest date
//if 3 months, change monitor boolean to true
//then create alert
//log the alert in user folder
//also save settings

public class Monitor{
	
	
	private int id; 
	
	private int testAvg;
	
	private int alertID;
	
	private int activityID;
	
	private boolean alertStatus;
	
	public boolean reminderStatus;
	
	public String lastMonth;
	
	private int abnormal;
	
	public boolean onOff = false;
	
	private String lastDate;
	
	private Report rep;
	
	private ArrayList<Integer> compare;
	
	private ArrayList<Activity> activities; //can also make private with add/remove/access methods
	
	private ArrayList<String> categories; 
	
	private ArrayList<String> dateParts; //0 is day, 1 is month, 2 is year
	
	
	
	public Monitor() {
		
	
		//read and write
		this.alertID = 0;
		
		this.activityID = 0;
		
		this.activities = new ArrayList<Activity>();
		
		this.compare = new ArrayList<Integer>();

		this.categories = new ArrayList<String>();
		

		
		this.categories.add("Blood");
		this.categories.add("Cardiovascular");
		this.categories.add("Gastrointestinal");
		this.categories.add("Respiratory");
		this.categories.add("Ultrasound");
		this.categories.add("X-Ray"); 
		this.categories.add("CT Scan");
		this.categories.add("ECG");
		
		this.lastDate = "0000-01-01";
		
		this.lastMonth = "";
		
	}
	
	
	
	public int getAbnormal() {
		
		return this.abnormal;
			
	}
	
	public int compareSize() {
		
		return this.compare.size();
	}
	
	public int activitiesSize() {
		
		return this.activities.size();
	}
	
	
	public int getAlertID() {
		
		return this.alertID;
	}
	
	public void setAlertID(int newID) {
		
		this.alertID = newID;
	}
	
	
	public int getActivityID() {
		
		return this.activityID;
	}
	
	public void setActivityID(int newID) {
		
		this.activityID = newID;
	}
	
	public boolean getAlertStatus() {
		
		return this.alertStatus;
	}
	
	
	
	//add alert object?
	//move to HealthSystem
	public void addActivity(HealthSystem hs, int fi, int rq, int em, int med, String date, String comment) {
		
		
		//save/load activities here
		
		//do pop up stuff here
		//add activities here
		if(this.alertStatus) {
			
			System.out.println("Here");
			this.setLastDate(hs);
			this.abnormal = 0;
			hs.dbSwap(false);	
			hs.runQuery("INSERT INTO lastdate VALUES('" + this.lastDate + "');", false);
			
			hs.dbSwap(true);
			++this.activityID;
			onOff = false;
			this.alertStatus = false;
		}
	
		hs.dbSwap(false);
		hs.runQuery("INSERT INTO activities VALUES(" + hs.current.getID() + ", '" + date + "', " + hs.current.getID() + ", " + fi + ", " + rq + ", " + em + ", " + med + ", '" + comment + "');", false);
		hs.dbSwap(true);

		
	}
	

	

	
	
	
	public boolean popUpReminder(HealthSystem hs) {
		
		if(this.dateParts != null) {
		
			this.emptyDateParts();
			
		}	
		
		
		
		this.getLastDate(hs);
		
		this.reminderStatus = true;
		
		String[] local = getLocalDate().split("-");
		
		for(int i=0; i<this.dateParts.size(); i++) {
			
			local[i] = local[i].trim();
			this.dateParts.get(i).trim();
		}
		
		int localYear = Integer.parseInt(local[2]);
		int localMonth = Integer.parseInt(local[1]);
		int localDay = Integer.parseInt(local[0]);
	
		int year = Integer.parseInt(this.dateParts.get(0));
		int month = Integer.parseInt(this.dateParts.get(1));
		int day = Integer.parseInt(this.dateParts.get(2));
		

		
		
		if(localYear == year && localDay >= day) {
			
			if(localMonth == month+3) {
				
				return true;
				
			}
			else {
				
				return false;
			}
		}
		
		return false;
		
	}
	
	
	

	
	
	
	public void checkAlertTriggered() {
		
	
			
			if(this.abnormal >= 3) {
				System.out.println("True");
				this.alertStatus = true;
			
				
			}
			else {
				
				this.alertStatus = false;
			}
			

		
	}
	
	
	
	/*public Exam getRecentResult(HealthSystem hs) {
	
		int examid=0;
		int testid=0;
		int userid=0;
		int status=0;
		Date date;
		String textdate = "";
		
		Exam ex = null;
		
		
		//test id turns into category
		//date turns into string
		
		try {
		
			hs.runQuery("SELECT * FROM Exam_Results", true);
			while(hs.rs.next()) {
			
				examid = hs.rs.getInt("Exam_ID)");
				testid = hs.rs.getInt("Test_ID");
				userid = hs.rs.getInt("User_ID");
				status = hs.rs.getInt("Status");
				date = hs.rs.getDate("Date");
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				textdate = formatter.format(date);
				//date
				
			}
				
			
		}catch(SQLException e) {
		
			
			e.printStackTrace();
		}

		//temporary tests
		//will add rest with calculations based on sorted avgs
		switch(testid) {
		
		case 1: 
			ex = new BloodTest(textdate, "Blood", status, userid);
			break;
		
		case 2:
			ex = new CardiovascularTest(textdate, "Cardiovascular", status, userid);
			break;
			
		case 3:	
			ex = new GastrointestinalTest(textdate, "Gastrointestinal", status, userid);
			break;
			
		case 4:
			ex = new RespiratoryTest(textdate, "Respiratory", status, userid);
			break;
		
		}
			
		
		return ex;
	}*/
	
	
	
	
	public void scanResults(HealthSystem hs, String function, int fi, int rq, int em, int med, String date) {
		
		//use status for now
		//< 50
		
		
		//load lastdate here
		try {
			hs.dbSwap(false);
			hs.runQuery("SELECT * FROM lastdate", true);
			
			while(hs.rs.next()) {
				
				this.lastDate = hs.rs.getString("Date");
				System.out.println(this.lastDate);
			}
			System.out.println(lastDate);
					
					
			hs.dbSwap(true);
		}catch(SQLException e) {
			
			e.printStackTrace();
		}
		
		
		for(int i=0; i<this.categories.size(); i++) {
			
			this.abnormal = 0;
			
			try {
			
			//get past 3 months
				hs.runQuery("SELECT * FROM Exam_Results", true);
			
				while(hs.rs.next()) {
				
				

					if(hs.rs.getInt("User_ID") == hs.current.getID() && hs.matchTestID(hs.rs.getInt("Test_ID")) == this.categories.get(i)) {
						
						//compare date here
						LocalDate last = LocalDate.parse(this.lastDate);
						LocalDate examdate = LocalDate.parse(hs.rs.getString("Date"));
						
						if(hs.rs.getInt("Status") == 0 && examdate.isAfter(last)) {
							++this.abnormal;
							
							
						}
					
						
							
						if(this.abnormal >= 3) {
							System.out.println("True");
							this.checkAlertTriggered();
						}
						
				
							
						
						}
					
						
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	//	this.popUpReminder(hs);
		
	}
	
	
	
	public void sortActivities() {
		
		Collections.sort(this.activities);
		
		
	}
	
	
	
	public void breakString(String toSplit, String delimiter) {
		
		String[] parts = toSplit.split(delimiter);
		this.dateParts = new ArrayList<>(Arrays.asList(parts));
		
	}
	
	
	public void emptyDateParts() {
		
		this.dateParts.clear();
	}
	
	
	
	public void getLastDate(HealthSystem hs) {
		
		
		String lastDate = "";
		hs.dbSwap(false);
		hs.runQuery("SELECT * FROM activities", true);
		
		try {
			
			while(hs.rs.next()) {
				
				
				lastDate = hs.rs.getString("Date");
				
			}
			
		}catch(SQLException e) {
			
			e.printStackTrace();
		}
		
		//for reports
		
		if(lastDate != "") {
			breakString(lastDate, "-");
			
		}	
		
		hs.dbSwap(true);
	}
	
	
	public String getLocalDate() {
		
		LocalDate ld = LocalDate.now();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		String today = ld.format(formatter);
		
		
		return today;
	}
	
	
	public void setLastDate(HealthSystem hs) {
		
		hs.dbSwap(true);
		
		try {
			
			hs.runQuery("SELECT * FROM Exam_Results;", true);
			
			while(hs.rs.next()) {
				
				this.lastDate = hs.rs.getString("Date");
				
			}
			
		}catch(SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	
	public void setLastMonth(HealthSystem hs) {
		
		hs.dbSwap(false);
		
		try {
			
			hs.runQuery("SELECT * FROM activities", true);
			
			while(hs.rs.next()) {
				
				this.lastMonth = hs.rs.getString("Date");
				
			}
			
		}catch(SQLException e) {
			
			e.printStackTrace();
		}
		
		
	}

	
	
			
		
}
	
