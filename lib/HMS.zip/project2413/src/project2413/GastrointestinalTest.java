package project2413;


public class GastrointestinalTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	GastrointestinalTest(String date, int id, String category, int status, int User_ID){
		
		super(date, id, "Gastrointestinal", status, User_ID);
		
	}
	

	public void enterResults(String stoolSampleType, String analysis) {
		
		
		
	}
	
}