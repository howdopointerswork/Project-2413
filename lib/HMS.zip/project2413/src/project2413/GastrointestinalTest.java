package project2413;


public class GastrointestinalTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	GastrointestinalTest(String date, int id){
		
		super(date, id);
		
	}
	

	public void enterResults(String stoolSampleType, String analysis) {
		
		
		
	}
	
}