package project2413;

import java.util.Scanner;

import project2413.Exam;
import project2413.HealthSystem;
import project2413.Loader;
import project2413.Monitor;
import project2413.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;
import project2413.*;

public class Main{
	
	public static void main(String[] args) {
		
		String username;
		
		String password;
		
		int choice = -1; //for loop
		
		
		
	  
	    EventQueue.invokeLater(() -> {
	     try {
	         MainFrame frame = new MainFrame();
	         frame.setVisible(true);
	          } catch (Exception e) {
	                e.printStackTrace();
	           }
	        });
	    
	    
	   

		
		//while(hs.getAuthenticated() == false) {
			
			
			
		
			/*switch(hs.loggedOutMenu()) {
		
			case 1:
			
				System.out.print("Enter username: ");
				//user name text field use here
				username = hs.scan.nextLine();
			
				System.out.println();
				//pass word text field here
				System.out.print("Enter password: ");
			
				password = hs.scan.nextLine();
			
				System.out.println();
			
				hs.current = new User(hs.logIn(username, password), username, password);
			
				if(hs.getAuthenticated()) {
					choice = -1;
					ldr.loadVars(hs, mon);
					System.out.println();
					System.out.println("Signed in as: " + hs.current.getUsername());
				}
			
				//for loop for checking users here
				break;
			
			case 2:
			
			
				System.out.print("Enter username: ");
				//user name text field use here
				username = hs.scan.nextLine();
			
				System.out.println();
				//pass word text field here
				System.out.print("Enter password: ");
			
				password = hs.scan.nextLine();
			
				System.out.println();
			
				hs.current = hs.signUp(username, password);
				//change hard code
				
				if(hs.getAuthenticated()) {
					choice = -1;
					System.out.println("Signed up successfully");
				
				}
				break;
		
		}
		
	}*/
		
		
	
	    
	    
	    /*
		while(choice != 0)	{ //main loop
			
			 //display logged out menu (replace with GUI)
			
			
			
			if(hs.getAuthenticated()) { //check if user matches credentials in db
				int option = hs.loggedInMenu();
		
				
				switch(option) {
				
				case 1:
					
					//Add Result
					System.out.println("How many exams?");
					int exams = hs.scan.nextInt();
					hs.scan.nextLine();
					
					for(int i=0; i<exams; i++) {
						
						System.out.println("Enter date:");
						String date = hs.scan.nextLine();
						System.out.println("Enter category:");
						String category = hs.scan.nextLine();
						System.out.println("Enter status:");
						int status = hs.scan.nextInt();
						hs.scan.nextLine();
						Exam e = new Exam(date, hs.getExamID(), category, status, hs.current.getID());
						
						e = e.enterResults(hs);
						System.out.println(e.getCategory());
						hs.addResult(e);
						
						
					}
				
					break;
					
				
				case 2:
					hs.editResult();
					//Edit Result
					break;
					
					
				case 3:
					//Delete Result
					hs.deleteResult();
					break;
					
				
				case 4:
					
					//Monitor settings
					//allow for setting up of monitor before use
					//and add a function to monitor based on category
					
					if(hs.countRows() >= 3) {
						mon.scanResults(hs);
						mon.checkAlertTriggered(hs, "Test");
						
					}
					
					break;
					
				case 5:
					
					//activity management here
					break;
					
				case 6:
					
					hs.signOut(hs.current, ldr, hs, mon);
					choice = 0;
					break;
					
				default: 
					
					hs.loggedInMenu();
				
				
				}
			}
			
			System.out.println();
			
		}*/

	
	
		
	}
}