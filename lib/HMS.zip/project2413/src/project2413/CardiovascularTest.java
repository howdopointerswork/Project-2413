package project2413;


public class CardiovascularTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	CardiovascularTest(String date, String category, int status, int User_ID){
		
		super(date, 2, category, status, User_ID);
		
	}
	

	/*public void enterResults(int heartRate, int bloodPressure1, int bloodPressure2) {
		
		
		
	}*/
	
}