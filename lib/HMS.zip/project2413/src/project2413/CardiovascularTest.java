package project2413;


public class CardiovascularTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	CardiovascularTest(String date, int id, String category, int status, int User_ID){
		
		super(date, id, "Cardiovascular", status, User_ID);
		
	}
	

	/*public void enterResults(int heartRate, int bloodPressure1, int bloodPressure2) {
		
		
		
	}*/
	
}