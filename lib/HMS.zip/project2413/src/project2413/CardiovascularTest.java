package project2413;


public class CardiovascularTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	CardiovascularTest(String date, int id){
		
		super(date, id);
		
	}
	

	public void enterResults(int heartRate, int bloodPressure1, int bloodPressure2) {
		
		
		
	}
	
}