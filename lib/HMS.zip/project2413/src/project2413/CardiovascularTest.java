package project2413;


public class CardiovascularTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	CardiovascularTest(String date, String category, int id){
		
		super(date, category, id);
		
	}
	

	public void enterResults(int heartRate, int bloodPressure1, int bloodPressure2) {
		
		
		
	}
	
}