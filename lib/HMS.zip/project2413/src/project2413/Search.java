package cscorner;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Search extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel centerPanel;
    private JTextField searchField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JLabel toLabel; 
    private JButton searchButton;
    private JComboBox<String> searchTypeComboBox;
    private JCheckBox abnormalResultsCheckBox;
    private int searchFontSize = 26;

    public Search() {
        setTitle("Search Exam Records");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 800);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        // Set up content pane
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        // Top panel with back, home, and logout buttons
        JPanel topPanel = new JPanel(new BorderLayout());

        // Panel for the Instructions button on the left
        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        JButton instructionsButton = new JButton("Instructions"); // Changed label to "Instructions"
        instructionsButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        instructionsButton.addActionListener(e -> showInstructions()); // Implement the method to show instructions
        leftPanel.add(instructionsButton); // Add Instructions button to leftPanel

        // Existing button panel for back, home, and logout buttons on the right
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        Font buttonFont = new Font("Tahoma", Font.PLAIN, 20);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        backButton.addActionListener(e -> goBack());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        homeButton.addActionListener(e -> goHome());

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        logoutButton.addActionListener(e -> logout());

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);

        // Add both panels to the top panel
        topPanel.add(leftPanel, BorderLayout.WEST); // Instructions panel on the left
        topPanel.add(buttonPanel, BorderLayout.EAST); // Existing buttons on the right
        contentPane.add(topPanel, BorderLayout.NORTH);

        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel searchTypeLabel = new JLabel("Search by:");
        searchTypeLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeLabel);

        // Dropdown menu for search type
        searchTypeComboBox = new JComboBox<>(new String[]{"Exam Type", "Date"});
        searchTypeComboBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeComboBox);

        JLabel searchLabel = new JLabel("Enter value:");
        searchLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchLabel);

        // Search field for single text input (search by category) 
        searchField = new JTextField(15);
        searchField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchField);

        // Start and End date fields for date search (only visible if Date type is selected)
        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        startDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        endDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        startDateField.setVisible(false);
        endDateField.setVisible(false);

        toLabel = new JLabel("to");
        toLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        toLabel.setVisible(false); // to is hidden initially because otherwise it makes no sense

        searchPanel.add(startDateField);
        searchPanel.add(toLabel);
        searchPanel.add(endDateField);

        // Search button
        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, searchFontSize));
        searchButton.addActionListener(e -> searchRecords());
        searchPanel.add(searchButton);

        abnormalResultsCheckBox = new JCheckBox("Only show abnormal results");
        abnormalResultsCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(abnormalResultsCheckBox);

        centerPanel.add(searchPanel);
        contentPane.add(centerPanel, BorderLayout.CENTER);

        //  listener to search type combo box to toggle fields
        searchTypeComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                toggleSearchField();
            }
        });
    }
    
    private void showInstructions() {
        // JTextArea for the instructions
        JTextArea instructionsArea = new JTextArea();
        instructionsArea.setText("Instructions:\n" +
                "1. Use the dropdown to select the search criteria (Exam Type or Date).\n" +
                "2. Enter your search term or dates in the provided fields.\n" +
                "3. Click 'Search' to view results.\n" +
                "4. Check 'Only show abnormal results' to filter results accordingly.");

        // Set the font size
        instructionsArea.setFont(new Font("Tahoma", Font.PLAIN, 18)); 
        instructionsArea.setEditable(false); 
        instructionsArea.setLineWrap(true); 
        instructionsArea.setWrapStyleWord(true); 
        
        // TODO: see how this looks on other monitors / resolutions
        instructionsArea.setPreferredSize(new Dimension(600, 400)); 

        // TODO: test on other resolutions to see if scroll is even necessary
        JScrollPane scrollPane = new JScrollPane(instructionsArea);
        scrollPane.setPreferredSize(new Dimension(600, 400)); 

        JOptionPane.showMessageDialog(this, scrollPane, "Instructions", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Toggle search between 1 ^& 2 search fields for customer selecting "date" as search type
    private void toggleSearchField() {
        if ("Date".equals(searchTypeComboBox.getSelectedItem())) {
            searchField.setVisible(false);
            startDateField.setVisible(true);
            endDateField.setVisible(true);
            toLabel.setVisible(true);
        } else {
            searchField.setVisible(true);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
        }
        centerPanel.revalidate();
        centerPanel.repaint();
    }

    // Method to simulate searching and displaying records in the center panel
    private void searchRecords() {
        centerPanel.removeAll();

        String searchType = (String) searchTypeComboBox.getSelectedItem();
        String searchText = searchField.getText();
        String startDate = startDateField.getText();
        String endDate = endDateField.getText();
        boolean showAbnormalResults = abnormalResultsCheckBox.isSelected();

        if ("Exam Type".equals(searchType) && searchText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search term.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else if ("Date".equals(searchType) && (startDate.isEmpty() || endDate.isEmpty())) {
            JOptionPane.showMessageDialog(this, "Please enter both start and end dates.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JLabel resultLabel = new JLabel("Search Type: " + searchType +
                " | Search Term: " + (searchType.equals("Date") ? startDate + " to " + endDate : searchText) +
                " | Abnormal Results Only: " + showAbnormalResults);
        resultLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        centerPanel.add(resultLabel);

        JLabel placeholderLabel = new JLabel("Search results will be displayed here...");
        placeholderLabel.setFont(new Font("Tahoma", Font.ITALIC, 18));
        centerPanel.add(placeholderLabel);

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void goBack() {
        if (!UserHomePage.pageHistory.isEmpty()) {
            JFrame previousPage = UserHomePage.pageHistory.pop();
            previousPage.setVisible(true);
            dispose();
        } else {
            showCustomMessage("No previous page.");
        }
    }

    private void goHome() {
        UserHomePage.pageHistory.clear();
        new UserHomePage().setVisible(true);
        dispose();
    }

    private void logout() {
        UserHomePage.pageHistory.clear();
        new UserLoginPage().setVisible(true);
        dispose();
    }

    private void showCustomMessage(String message) {
        JLabel messageLabel = new JLabel(message);
        messageLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        JOptionPane.showMessageDialog(this, messageLabel, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Search frame = new Search();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
