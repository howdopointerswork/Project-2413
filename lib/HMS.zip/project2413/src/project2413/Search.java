package project2413;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import java.util.ArrayList;
import java.util.Arrays;
import java.awt.*;
import java.security.interfaces.RSAKey;
import java.sql.SQLException;
import java.util.HashMap;
import java.time.*;
import java.sql.*;
import java.awt.event.*;


public class Search extends JPanel {
    private static final long serialVersionUID = 1L;
    private MainFrame mainFrame;
    private JPanel centerPanel;
    private JTextField searchField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JLabel toLabel;
    private JButton searchButton;
    private JComboBox<String> searchTypeComboBox;
    private JCheckBox abnormalResultsCheckBox;
    private JCheckBox foodIntakeCheckBox, restQualityCheckBox, emotionCheckBox, medicationCheckBox;
    private JCheckBox bloodCheckBox, cardiovascularCheckBox, gastrointestinalCheckBox, respiratoryCheckBox;
    private JCheckBox ultrasoundCheckBox, xrayCheckBox, ctScanCheckBox, ecgCheckBox;
    private JCheckBox activityTypeCheckBox1, activityTypeCheckBox2, activityTypeCheckBox3, activityTypeCheckBox4; 
    private int searchFontSize = 26;
    private  HashMap<Integer,JCheckBox> map; 
    private HashMap<Integer, JCheckBox> map2;
    private boolean noCheck = true; //for when only abnormal is checked
    private  ActionListener act1;
    private ActionListener act2;
    private JTable resultTable;
    private DefaultTableModel tableModel;
    private Object[][] data = {};

    public Search(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.map = new HashMap<Integer,JCheckBox>();
        this.map2 = new HashMap<Integer,JCheckBox>();
        this.act1 = e -> searchRecords(true);
        this.act2 = e -> searchRecords(false);
        setLayout(new BorderLayout());
        add(createTopPanel(), BorderLayout.NORTH);
        add(createSideMenu(), BorderLayout.WEST);
        initializeComponents();
        
        setupExamSearch();  // default search type is Exam Type
    }

    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.addActionListener(e -> goBack());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(buttonFont);
        homeButton.addActionListener(e -> goHome());

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(buttonFont);
        logoutButton.addActionListener(e -> logout());

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        return topPanel;
    }

    private JPanel createSideMenu() {
        JPanel leftMenuPanel = new JPanel();
        leftMenuPanel.setLayout(new BorderLayout());
        leftMenuPanel.setPreferredSize(new Dimension(200, 0));

        JLabel menuLabel = new JLabel("MENU", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
        leftMenuPanel.add(menuLabel, BorderLayout.NORTH);

        JPanel menuButtonsPanel = new JPanel();
        menuButtonsPanel.setLayout(new GridLayout(5, 1, 10, 10));

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 26);

        JButton myExamsButton = new JButton("<html><div align='center'>Search My<br>Exams</div></html>");
        myExamsButton.setFont(buttonFont);
        myExamsButton.addActionListener(e -> setupExamSearch());

        JButton myActivitiesButton = new JButton("<html><div align='center'>Search My<br>Activities</div></html>");
        myActivitiesButton.setFont(buttonFont);
        myActivitiesButton.addActionListener(e -> setupActivitySearch());

        menuButtonsPanel.add(myExamsButton);
        menuButtonsPanel.add(myActivitiesButton);
        leftMenuPanel.add(menuButtonsPanel, BorderLayout.CENTER);

        return leftMenuPanel;
    }

    private void initializeComponents() {
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        JLabel searchTypeLabel = new JLabel("Search by:");
        searchTypeLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeLabel);

        searchTypeComboBox = new JComboBox<>(new String[]{"Exam Type", "Date"});
        searchTypeComboBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeComboBox);

        JLabel searchLabel = new JLabel("Enter value:");
        searchLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchLabel);

        searchField = new JTextField(15);
        searchField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchField);

        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        startDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        endDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        startDateField.setVisible(false);
        endDateField.setVisible(false);

        toLabel = new JLabel("to");
        toLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        toLabel.setVisible(false);

        searchPanel.add(startDateField);
        searchPanel.add(toLabel);
        searchPanel.add(endDateField);

        // Exam Type checkboxes
        bloodCheckBox = createExamCheckBox("Blood");
        cardiovascularCheckBox = createExamCheckBox("Cardiovascular");
        gastrointestinalCheckBox = createExamCheckBox("Gastrointestinal");
        respiratoryCheckBox = createExamCheckBox("Respiratory");
        ultrasoundCheckBox = createExamCheckBox("Ultrasound");
        xrayCheckBox = createExamCheckBox("X-Ray");
        ctScanCheckBox = createExamCheckBox("CT Scan");
        ecgCheckBox = createExamCheckBox("ECG");

        searchPanel.add(bloodCheckBox);
        searchPanel.add(cardiovascularCheckBox);
        searchPanel.add(gastrointestinalCheckBox);
        searchPanel.add(respiratoryCheckBox);
        searchPanel.add(ultrasoundCheckBox);
        searchPanel.add(xrayCheckBox);
        searchPanel.add(ctScanCheckBox);
        searchPanel.add(ecgCheckBox);

        abnormalResultsCheckBox = new JCheckBox("Only show abnormal results");
        abnormalResultsCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(abnormalResultsCheckBox);

        // Activity Type checkboxes
        activityTypeCheckBox1 = createActivityCheckBox("Food Intake");
        activityTypeCheckBox2 = createActivityCheckBox("Rest Quality");
        activityTypeCheckBox3 = createActivityCheckBox("Emotion");
        activityTypeCheckBox4 = createActivityCheckBox("Medication");
        searchPanel.add(activityTypeCheckBox1);
        searchPanel.add(activityTypeCheckBox2);
        searchPanel.add(activityTypeCheckBox3);
        searchPanel.add(activityTypeCheckBox4);

        centerPanel.add(searchPanel); 

        // Search Button
        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, searchFontSize));
        searchPanel.add(searchButton);

        // spacer - between search components and table. we can change if needed 
        centerPanel.add(Box.createVerticalStrut(5));  

        // Table 
        String[] columnNames = {"Date", "Exam Type", "Result", "Abnormality", "Modify", "Delete"};
       // Object[][] data = {}; // blank initially 

        tableModel = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // cell 4 & 5 (modify & delete) will not be editable 
                return column != 4 && column != 5;
            }
        };

        resultTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(resultTable);
        resultTable.setFillsViewportHeight(true); 

        // modify & delete buttons in last 2 cols of table 
        resultTable.getColumn("Modify").setCellRenderer(new ButtonRenderer());
        resultTable.getColumn("Delete").setCellRenderer(new ButtonRenderer());

        resultTable.getColumn("Modify").setCellEditor(new ButtonEditor(new JCheckBox()));
        resultTable.getColumn("Delete").setCellEditor(new ButtonEditor(new JCheckBox()));

        centerPanel.add(tableScrollPane);  

        add(centerPanel, BorderLayout.CENTER);

        searchTypeComboBox.addActionListener(e -> toggleSearchField());
    }
    
    public class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value == null) {
                return this;
            }
            setText(value.toString());
            return this;
        }
    }
    
    public class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private String label;
        private boolean isPushed;
        private JTable table;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);

            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                    int row = table.getSelectedRow();
                    if (isPushed) {
                        // Modify Button logic: Turn row into editable text fields
                        if (button.getText().equals("Modify")) {
                            makeRowEditable(row);
                        }
                        // Delete Button logic: Remove the row
                        else if (button.getText().equals("Delete")) {
                            ((DefaultTableModel) table.getModel()).removeRow(row);
                        }
                    }
                    isPushed = false;
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.table = table;
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isPushed = true;
            return button;
        }

        public Object getCellEditorValue() {
            return label;
        }

        private void makeRowEditable(int row) {
            for (int col = 0; col < table.getColumnCount() - 2; col++) {
                table.setValueAt(new JTextField(table.getValueAt(row, col).toString()), row, col);
            }
        }
    }

    private JCheckBox createExamCheckBox(String label) {
        JCheckBox checkBox = new JCheckBox(label);
        checkBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        checkBox.setVisible(false);
        return checkBox;
    }

    private JCheckBox createActivityCheckBox(String label) {
        JCheckBox checkBox = new JCheckBox(label);
        checkBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        checkBox.setVisible(false);
        return checkBox;
    }

    private void setupExamSearch() {
        searchTypeComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Exam Type", "Date"}));
        abnormalResultsCheckBox.setVisible(true);
        toggleSearchField();
        revalidate();
        repaint();
        searchButton.removeActionListener(act2);
        searchButton.addActionListener(act1);
    }

    private void setupActivitySearch() {
        searchTypeComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Activity Type", "Date"}));
        abnormalResultsCheckBox.setVisible(false);
        
        toggleSearchField();
        revalidate();
        repaint();
        
        searchButton.removeActionListener(act1);
        searchButton.addActionListener(act2);
     
    }

    private void toggleSearchField() {
        String selectedType = (String) searchTypeComboBox.getSelectedItem();
        
        if ("Date".equals(selectedType)) {
            searchField.setVisible(false);
            startDateField.setVisible(true);
            endDateField.setVisible(true);
            toLabel.setVisible(true);
            setExamCheckBoxesVisible(false);
            setActivityCheckBoxesVisible(false);
        } else if ("Exam Type".equals(selectedType)) {
            searchField.setVisible(false);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            setExamCheckBoxesVisible(true);
            setActivityCheckBoxesVisible(false);
        } else if ("Activity Type".equals(selectedType)) {
            searchField.setVisible(false);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            setExamCheckBoxesVisible(false);
            setActivityCheckBoxesVisible(true);
        } else {
            searchField.setVisible(true);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            setExamCheckBoxesVisible(false);
            setActivityCheckBoxesVisible(false);
        }

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void setExamCheckBoxesVisible(boolean visible) {
        bloodCheckBox.setVisible(visible);
        cardiovascularCheckBox.setVisible(visible);
        gastrointestinalCheckBox.setVisible(visible);
        respiratoryCheckBox.setVisible(visible);
        ultrasoundCheckBox.setVisible(visible);
        xrayCheckBox.setVisible(visible);
        ctScanCheckBox.setVisible(visible);
        ecgCheckBox.setVisible(visible);
    }

    private void setActivityCheckBoxesVisible(boolean visible) {
        activityTypeCheckBox1.setVisible(visible);
        activityTypeCheckBox2.setVisible(visible);
        activityTypeCheckBox3.setVisible(visible);
        activityTypeCheckBox4.setVisible(visible);
        
    }

    private void searchRecords(boolean tf) {
        // TODO: connect to backend function
    	
    	//add row example
    	//Object[] newRow = {"Test", "Test", "Test"};
    	//tableModel.addRow(newRow);
    	
    	//String[] arr = {"Food Intake", "Rest Quality", "Emotion", "Medicine"};
		 
    	tableModel.setRowCount(0);
    	
		 if(tf) {
			 map.put(1,bloodCheckBox);
			 map.put(2,cardiovascularCheckBox);
			 map.put(3,gastrointestinalCheckBox); 
			 map.put(4,respiratoryCheckBox);
			 map.put(5,ultrasoundCheckBox);
			 map.put(6,xrayCheckBox); 
			 map.put(7,ctScanCheckBox); 
			 map.put(8,ecgCheckBox);
		 }
		 else {
			 
			 map2.put(1, activityTypeCheckBox1);
			 map2.put(2, activityTypeCheckBox2);
			 map2.put(3, activityTypeCheckBox3);
			 map2.put(4, activityTypeCheckBox1);
			 
		 }
		 
    	
    	if(tf) {
    		
    		if(searchTypeComboBox.getSelectedItem() == "Exam Type") {
    			
    			
    			this.mainFrame.hs.dbSwap(false);
    			
    			map.forEach((key,box)->{
 
    				this.mainFrame.hs.runQuery("SELECT * FROM categories;", true);
    				
    				try {
    					
    					while(this.mainFrame.hs.rs.next()) {
    			
    						if(box.isSelected() && this.mainFrame.hs.rs.getInt("Test_ID") == key) {
    						
    							if(abnormalResultsCheckBox.isSelected() && this.mainFrame.hs.rs.getInt("Status") == 0) {
    								//{"Date", "Exam Type", "Result", "Abnormality", "Modify", "Delete"};
    								Object[] newRow = {this.mainFrame.hs.rs.getString("Date"), this.mainFrame.hs.rs.getString("Name"), " ", this.mainFrame.hs.rs.getInt("Status")};
    								tableModel.addRow(newRow);
    								
    							}
    							else {
    				    			
    								Object[] newRow = {this.mainFrame.hs.rs.getString("Date"), this.mainFrame.hs.rs.getString("Name"), " ", this.mainFrame.hs.rs.getInt("Status")};
    								tableModel.addRow(newRow);
    				    			
    				    		}
    						}
    					}
    				}catch(SQLException e) {
    					
    					e.printStackTrace();
    				}
    				
    			});
    		}
    		
    		else {
    			
    			this.mainFrame.hs.dbSwap(false);
    			
    			this.mainFrame.hs.runQuery("SELECT * FROM categories;", true);
    			
    			String dt;
    			
    			try {
    				
    				while(this.mainFrame.hs.rs.next()) {
    					
    					
    					if(startDateField.getText() != "" && endDateField.getText() != "") {
    							if(this.mainFrame.hs.rs.getString("Date") == null) {
    								
    								dt = "2024-01-01";
    							}
    							else {
    								
    								dt = this.mainFrame.hs.rs.getString("Date");
    							}
    						 	LocalDate date = LocalDate.parse(dt);
    						 	LocalDate start = LocalDate.parse(startDateField.getText()); LocalDate end =
    						 	LocalDate.parse(endDateField.getText());
    						  
    						  
    						 	if(date.isAfter(start) && date.isBefore(end)) {
    						  
    						 		Object[] newRow = {this.mainFrame.hs.rs.getString("Date"), this.mainFrame.hs.rs.getString("Name"), " ", this.mainFrame.hs.rs.getInt("Status")};
    								tableModel.addRow(newRow);
    						  	
    						  
    						  	} 
    						  
    						  } 
    						  
    						 }
    						  
    						}catch(SQLException e) {
    						  
    						  e.printStackTrace(); 
    						}
    						  
    			}			
    		
    	}
    	else {
    		
    		if(searchTypeComboBox.getSelectedItem() == "Activity Type") {
    			
    			this.mainFrame.hs.dbSwap(false);
    			
    			map2.forEach((key, box)->{
    				
    				this.mainFrame.hs.runQuery("SELECT * FROM activities;", true);
    				
    				try {
    					
    					while(this.mainFrame.hs.rs.next()) {
    						
    						//fix after
    						if(box.isSelected()) {
    							 switch(key) {
    							  
    							  case 1: System.out.println(this.mainFrame.hs.rs.getInt("food_intake"));
    							  break;
    							  
    							  case 2:
    							  
    							  System.out.println(this.mainFrame.hs.rs.getInt("rest_quality")); break;
    							  
    							  case 3:
    							  
    							  System.out.println(this.mainFrame.hs.rs.getInt("emotion")); break;
    							  
    							  case 4:
    							  
    							  System.out.println(this.mainFrame.hs.rs.getInt("medicine")); break;
    							  
    							  }
    							
    						}
    					}
    					
    				}catch(SQLException e) {
    					
    					e.printStackTrace();
    				}
    			});
    			
    			
    			
    		}
    		
    		else {
    			
    			
    			this.mainFrame.hs.dbSwap(false);
    			
    			this.mainFrame.hs.runQuery("SELECT * FROM activities;", true);
    			
    			try {
    				
    				while(this.mainFrame.hs.rs.next()) {
    					
    					  if(startDateField.getText() != "" && endDateField.getText() != "") {
    						  LocalDate date = LocalDate.parse(this.mainFrame.hs.rs.getString("Date"));
    						  LocalDate start = LocalDate.parse(startDateField.getText()); LocalDate end =
    						  LocalDate.parse(endDateField.getText());
    						  
    						  
    						  if(date.isAfter(start) && date.isBefore(end)) {
    						  
    						  //activity id here System.out.println("Activity ID: " +
    							 
    							  //add medicine
    							  Object[] newRow = {this.mainFrame.hs.rs.getString("Date"), this.mainFrame.hs.rs.getInt("food_intake"), this.mainFrame.hs.rs.getInt("rest_quality"), this.mainFrame.hs.rs.getInt("emotion")};
  								  tableModel.addRow(newRow);
  						  	
    						  } 
    						  
    					  } 
    				}
    				
    			}catch(SQLException e) {
    				
    				e.printStackTrace();
    			}
    		}
    		
    	}
    	
    	this.mainFrame.hs.dbSwap(true);
    
    	for (int i = 0; i < resultTable.getRowCount(); i++) {
    		
    	    final int index = i;  // Make sure this is final
    	    JButton deleteButton = new JButton("Delete");
    	    deleteButton.addActionListener(e -> deleteRecord(index));  

    	    JButton modifyButton = new JButton("Modify");
    	    modifyButton.addActionListener(e -> modifyRecord(index));  


            resultTable.setValueAt(deleteButton, i, 4); // to house delete button
            resultTable.setValueAt(modifyButton, i, 5); //to house modify button
        }
    	
    }
    	
    	//check either exam type or date
    	
    	
    		private Object modifyRecord(int i) {
		// TODO Auto-generated method stub
		return null;
	}

			private Object deleteRecord(int i) {
		// TODO Auto-generated method stub
		return null;
	}
/*
			 * 
			 * } else {
			 * 
			 * 
			 * 
			 * 
			 * try { this.mainFrame.hs.dbSwap(false);
			 * this.mainFrame.hs.runQuery("SELECT * FROM activities;", true);
			 * 
			 * 
			 * 
			 * while(this.mainFrame.hs.rs.next()) { this.mainFrame.hs.dbSwap(false);
			 * 
			 * // this.dateParts = new ArrayList<>(Arrays.asList(parts));
			  if(startDateField.getText() != "" && endDateField.getText() != "") {
			  LocalDate date = LocalDate.parse(this.mainFrame.hs.rs.getString("Date"));
			  LocalDate start = LocalDate.parse(startDateField.getText()); LocalDate end =
			  LocalDate.parse(endDateField.getText());
			  
			  
			  if(date.isAfter(start) && date.isBefore(end)) {
			  
			  //activity id here System.out.println("Activity ID: " +
			  this.mainFrame.hs.rs.getInt("Activity ID")); System.out.println("Date: " +
			  this.mainFrame.hs.rs.getString("Date")); System.out.println("Food Intake: " +
			  this.mainFrame.hs.rs.getInt("food_intake"));
			  System.out.println("Rest Quality: " +
			  this.mainFrame.hs.rs.getInt("rest_quality")); System.out.println("Emotion: "
			  + this.mainFrame.hs.rs.getInt("emotion")); System.out.println("Medicine: " +
			  this.mainFrame.hs.rs.getInt("medicine")); System.out.println(); } } }
			  
			 * }catch(SQLException e) {
			 * 
			 * e.printStackTrace(); }
			 * 
			 * }
			 * 
			 * 
			 * }
			 * 
			 * this.mainFrame.hs.dbSwap(true);
			 * 
			 * 
			 * }
			 * 
			 * 
			 * 
			 * 
			 * 
			 * 
			 * 
			 * //exam type
			 * 
			 * //check checked boxes on exams here
			 * 
			 * 
			 * 
			 * //date //match date here
			 * 
			 * 
			 * //implement activities here
			 */    	
    
    

    private void goBack() {
        mainFrame.showPreviousPage();
    }

    private void goHome() {
        mainFrame.showHomePage();
    }

    private void logout() {
        mainFrame.logout();
    }
}
