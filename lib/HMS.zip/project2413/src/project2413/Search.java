package cscorner;

import javax.swing.*;
import java.awt.*;

public class Search extends JPanel {
    private static final long serialVersionUID = 1L;
    private MainFrame mainFrame;
    private JPanel centerPanel;
    private JTextField searchField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JLabel toLabel;
    private JButton searchButton;
    private JComboBox<String> searchTypeComboBox;
    private JCheckBox abnormalResultsCheckBox;
    private JCheckBox foodIntakeCheckBox, restQualityCheckBox, emotionCheckBox, medicationCheckBox;
    private int searchFontSize = 26;

    // Constructor accepting MainFrame
    public Search(MainFrame mainFrame) {
        this.mainFrame = mainFrame;

        setLayout(new BorderLayout());

        // Add the top panel with navigation buttons
        add(createTopPanel(), BorderLayout.NORTH);

        // Add the side menu panel
        add(createSideMenu(), BorderLayout.WEST);

        // Initialize the center panel components
        initializeComponents();
    }

    // Create a top panel with Back, Home, and Logout buttons
    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.addActionListener(e -> goBack());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(buttonFont);
        homeButton.addActionListener(e -> goHome());

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(buttonFont);
        logoutButton.addActionListener(e -> logout());

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        return topPanel;
    }

    // Create a side menu panel with "My Exams" and "My Activities" options
    private JPanel createSideMenu() {
        JPanel leftMenuPanel = new JPanel();
        leftMenuPanel.setLayout(new BorderLayout());
        leftMenuPanel.setPreferredSize(new Dimension(200, 0));

        // Create and add the menu label at the top
        JLabel menuLabel = new JLabel("MENU", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
        leftMenuPanel.add(menuLabel, BorderLayout.NORTH);

        // Create a panel for the menu buttons
        JPanel menuButtonsPanel = new JPanel();
        menuButtonsPanel.setLayout(new GridLayout(5, 1, 10, 10)); // Adjusted for two buttons

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 26);

        // Create "My Exams" button
        JButton myExamsButton = new JButton("<html><div align='center'>Search My<br>Exams</div></html>");
        myExamsButton.setFont(buttonFont);
        myExamsButton.addActionListener(e -> setupExamSearch());

        // Create "My Activities" button
        JButton myActivitiesButton = new JButton("<html><div align='center'>Search My<br>Activites</div></html>");
        myActivitiesButton.setFont(buttonFont);
        myActivitiesButton.addActionListener(e -> setupActivitySearch());

        // Add buttons to the menu panel
        menuButtonsPanel.add(myExamsButton);
        menuButtonsPanel.add(myActivitiesButton);

        // Add the button panel to the center of the left menu panel
        leftMenuPanel.add(menuButtonsPanel, BorderLayout.CENTER);

        return leftMenuPanel;
    }

    private void initializeComponents() {
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        JLabel searchTypeLabel = new JLabel("Search by:");
        searchTypeLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeLabel);

        // Dropdown menu for search type
        searchTypeComboBox = new JComboBox<>(new String[]{"Exam Type", "Date"});
        searchTypeComboBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeComboBox);

        JLabel searchLabel = new JLabel("Enter value:");
        searchLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchLabel);

        // Search field for single text input
        searchField = new JTextField(15);
        searchField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchField);

        // Date fields
        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        startDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        endDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        startDateField.setVisible(false);
        endDateField.setVisible(false);

        toLabel = new JLabel("to");
        toLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        toLabel.setVisible(false);

        searchPanel.add(startDateField);
        searchPanel.add(toLabel);
        searchPanel.add(endDateField);

        // Create the checkboxes for Activity Type (initially hidden)
        foodIntakeCheckBox = new JCheckBox("Food Intake");
        restQualityCheckBox = new JCheckBox("Rest Quality");
        emotionCheckBox = new JCheckBox("Emotion");
        medicationCheckBox = new JCheckBox("Medication");

        foodIntakeCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        restQualityCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        emotionCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        medicationCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));

        // Add checkboxes to the panel (initially hidden)
        searchPanel.add(foodIntakeCheckBox);
        searchPanel.add(restQualityCheckBox);
        searchPanel.add(emotionCheckBox);
        searchPanel.add(medicationCheckBox);

        // Checkboxes are initially invisible
        foodIntakeCheckBox.setVisible(false);
        restQualityCheckBox.setVisible(false);
        emotionCheckBox.setVisible(false);
        medicationCheckBox.setVisible(false);

        // Search button
        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, searchFontSize));
        searchButton.addActionListener(e -> searchRecords());
        searchPanel.add(searchButton);

        abnormalResultsCheckBox = new JCheckBox("Only show abnormal results");
        abnormalResultsCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(abnormalResultsCheckBox);

        centerPanel.add(searchPanel);
        add(centerPanel, BorderLayout.CENTER);

        // Add listener to toggle fields based on search type selection
        searchTypeComboBox.addActionListener(e -> toggleSearchField());
    }

    private void setupExamSearch() {
        searchTypeComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Exam Type", "Date"}));
        abnormalResultsCheckBox.setVisible(true);
        toggleSearchField(); // Reset the visibility of fields based on selection
        revalidate();
        repaint();
    }

    private void setupActivitySearch() {
        searchTypeComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Activity Type", "Date"}));
        abnormalResultsCheckBox.setVisible(false); // Not relevant for activities
        toggleSearchField(); // Reset the visibility of fields based on selection
        revalidate();
        repaint();
    }

    private void toggleSearchField() {
        if ("Date".equals(searchTypeComboBox.getSelectedItem())) {
            // Show only start and end date fields, hide search field
            searchField.setVisible(false);  // Hide the search field
            startDateField.setVisible(true);
            endDateField.setVisible(true);
            toLabel.setVisible(true);
            
            // Hide checkboxes for activity type
            foodIntakeCheckBox.setVisible(false);
            restQualityCheckBox.setVisible(false);
            emotionCheckBox.setVisible(false);
            medicationCheckBox.setVisible(false);
        } else if ("Activity Type".equals(searchTypeComboBox.getSelectedItem())) {
            // Hide date fields and show checkboxes
            searchField.setVisible(false);  // Hide the search field
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            
            // Show checkboxes for activity type
            foodIntakeCheckBox.setVisible(true);
            restQualityCheckBox.setVisible(true);
            emotionCheckBox.setVisible(true);
            medicationCheckBox.setVisible(true);
        } else {
            // Default case for other search types (like "Exam Type")
            searchField.setVisible(true);  // Show the search field
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            
            // Hide checkboxes for activity type
            foodIntakeCheckBox.setVisible(false);
            restQualityCheckBox.setVisible(false);
            emotionCheckBox.setVisible(false);
            medicationCheckBox.setVisible(false);
        }
        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void searchRecords() {
        centerPanel.removeAll();

        String searchType = (String) searchTypeComboBox.getSelectedItem();
        String searchText = searchField.getText();
        String startDate = startDateField.getText();
        String endDate = endDateField.getText();
        boolean showAbnormalResults = abnormalResultsCheckBox.isSelected();

        JLabel resultLabel = new JLabel("Search Type: " + searchType +
                " | Search Term: " + (searchType.equals("Date") ? startDate + " to " + endDate : searchText) +
                " | Abnormal Results Only: " + showAbnormalResults);
        resultLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        centerPanel.add(resultLabel);

        // Show selected activity checkboxes
        if ("Activity Type".equals(searchTypeComboBox.getSelectedItem())) {
            StringBuilder activitySelections = new StringBuilder("Selected Activities: ");
            if (foodIntakeCheckBox.isSelected()) activitySelections.append("Food Intake ");
            if (restQualityCheckBox.isSelected()) activitySelections.append("Rest Quality ");
            if (emotionCheckBox.isSelected()) activitySelections.append("Emotion ");
            if (medicationCheckBox.isSelected()) activitySelections.append("Medication ");

            JLabel activityLabel = new JLabel(activitySelections.toString());
            activityLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
            centerPanel.add(activityLabel);
        }

        JLabel placeholderLabel = new JLabel("Search results will be displayed here...");
        placeholderLabel.setFont(new Font("Tahoma", Font.ITALIC, 18));
        centerPanel.add(placeholderLabel);

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void goBack() {
        mainFrame.showPreviousPage();
    }

    private void goHome() {
        mainFrame.showPage("Home");
    }

    private void logout() {
        mainFrame.showPage("Login");
    }
}
