package cscorner;

import javax.swing.*;
import java.awt.*;

public class Search extends JPanel {
    private static final long serialVersionUID = 1L;
    private MainFrame mainFrame; // Reference to MainFrame
    private JPanel centerPanel;
    private JTextField searchField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JLabel toLabel;
    private JButton searchButton;
    private JComboBox<String> searchTypeComboBox;
    private JCheckBox abnormalResultsCheckBox;
    private int searchFontSize = 26;

    // Constructor accepting MainFrame
    public Search(MainFrame mainFrame) {
        this.mainFrame = mainFrame; // Store reference to MainFrame

        setLayout(new BorderLayout());
        initializeComponents();
    }

    private void initializeComponents() {
        // Set up center panel and components like before
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel searchTypeLabel = new JLabel("Search by:");
        searchTypeLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeLabel);

        // Dropdown menu for search type
        searchTypeComboBox = new JComboBox<>(new String[]{"Exam Type", "Date"});
        searchTypeComboBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeComboBox);

        JLabel searchLabel = new JLabel("Enter value:");
        searchLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchLabel);

        // Search field for single text input (search by category) 
        searchField = new JTextField(15);
        searchField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchField);

        // Start and End date fields for date search (only visible if Date type is selected)
        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        startDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        endDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        startDateField.setVisible(false);
        endDateField.setVisible(false);

        toLabel = new JLabel("to");
        toLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        toLabel.setVisible(false); // initially hidden

        searchPanel.add(startDateField);
        searchPanel.add(toLabel);
        searchPanel.add(endDateField);

        // Search button
        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, searchFontSize));
        searchButton.addActionListener(e -> searchRecords());
        searchPanel.add(searchButton);

        abnormalResultsCheckBox = new JCheckBox("Only show abnormal results");
        abnormalResultsCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(abnormalResultsCheckBox);

        centerPanel.add(searchPanel);
        add(centerPanel, BorderLayout.CENTER);

        // Add listener to search type combo box to toggle fields
        searchTypeComboBox.addActionListener(e -> toggleSearchField());
    }

    // Toggle between search fields based on selection
    private void toggleSearchField() {
        if ("Date".equals(searchTypeComboBox.getSelectedItem())) {
            searchField.setVisible(false);
            startDateField.setVisible(true);
            endDateField.setVisible(true);
            toLabel.setVisible(true);
        } else {
            searchField.setVisible(true);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
        }
        centerPanel.revalidate();
        centerPanel.repaint();
    }

    // Simulate searching and displaying records in the center panel
    private void searchRecords() {
        centerPanel.removeAll();

        String searchType = (String) searchTypeComboBox.getSelectedItem();
        String searchText = searchField.getText();
        String startDate = startDateField.getText();
        String endDate = endDateField.getText();
        boolean showAbnormalResults = abnormalResultsCheckBox.isSelected();

        JLabel resultLabel = new JLabel("Search Type: " + searchType +
                " | Search Term: " + (searchType.equals("Date") ? startDate + " to " + endDate : searchText) +
                " | Abnormal Results Only: " + showAbnormalResults);
        resultLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        centerPanel.add(resultLabel);

        JLabel placeholderLabel = new JLabel("Search results will be displayed here...");
        placeholderLabel.setFont(new Font("Tahoma", Font.ITALIC, 18));
        centerPanel.add(placeholderLabel);

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void goBack() {
        // Logic to go back to the previous page
        // Example: MainFrame.switchToPreviousPanel();
    }

    private void goHome() {
        // Logic to go to home page
        // Example: MainFrame.switchToHomePanel();
    }

    private void logout() {
        // Logic to log out
        // Example: MainFrame.switchToLoginPanel();
    }
}
