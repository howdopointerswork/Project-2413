package project2413;

import javax.swing.*;
import java.awt.*;

public class Search extends JPanel {
    private static final long serialVersionUID = 1L;
    private MainFrame mainFrame;
    private JPanel centerPanel;
    private JTextField searchField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JLabel toLabel;
    private JButton searchButton;
    private JComboBox<String> searchTypeComboBox;
    private JCheckBox abnormalResultsCheckBox;
    private JCheckBox foodIntakeCheckBox, restQualityCheckBox, emotionCheckBox, medicationCheckBox;
    private JCheckBox bloodCheckBox, cardiovascularCheckBox, gastrointestinalCheckBox, respiratoryCheckBox;
    private JCheckBox ultrasoundCheckBox, xrayCheckBox, ctScanCheckBox, ecgCheckBox;
    private JCheckBox activityTypeCheckBox1, activityTypeCheckBox2, activityTypeCheckBox3, activityTypeCheckBox4; 
    private int searchFontSize = 26;

    public Search(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        add(createTopPanel(), BorderLayout.NORTH);
        add(createSideMenu(), BorderLayout.WEST);
        initializeComponents();
        
        setupExamSearch();  // default search type is Exam Type
    }

    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.addActionListener(e -> goBack());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(buttonFont);
        homeButton.addActionListener(e -> goHome());

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(buttonFont);
        logoutButton.addActionListener(e -> logout());

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        return topPanel;
    }

    private JPanel createSideMenu() {
        JPanel leftMenuPanel = new JPanel();
        leftMenuPanel.setLayout(new BorderLayout());
        leftMenuPanel.setPreferredSize(new Dimension(200, 0));

        JLabel menuLabel = new JLabel("MENU", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
        leftMenuPanel.add(menuLabel, BorderLayout.NORTH);

        JPanel menuButtonsPanel = new JPanel();
        menuButtonsPanel.setLayout(new GridLayout(5, 1, 10, 10));

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 26);

        JButton myExamsButton = new JButton("<html><div align='center'>Search My<br>Exams</div></html>");
        myExamsButton.setFont(buttonFont);
        myExamsButton.addActionListener(e -> setupExamSearch());

        JButton myActivitiesButton = new JButton("<html><div align='center'>Search My<br>Activities</div></html>");
        myActivitiesButton.setFont(buttonFont);
        myActivitiesButton.addActionListener(e -> setupActivitySearch());

        menuButtonsPanel.add(myExamsButton);
        menuButtonsPanel.add(myActivitiesButton);
        leftMenuPanel.add(menuButtonsPanel, BorderLayout.CENTER);

        return leftMenuPanel;
    }

    private void initializeComponents() {
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        JLabel searchTypeLabel = new JLabel("Search by:");
        searchTypeLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeLabel);

        searchTypeComboBox = new JComboBox<>(new String[]{"Exam Type", "Date"});
        searchTypeComboBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchTypeComboBox);

        JLabel searchLabel = new JLabel("Enter value:");
        searchLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchLabel);

        searchField = new JTextField(15);
        searchField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(searchField);

        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        startDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        endDateField.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        startDateField.setVisible(false);
        endDateField.setVisible(false);

        toLabel = new JLabel("to");
        toLabel.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        toLabel.setVisible(false);

        searchPanel.add(startDateField);
        searchPanel.add(toLabel);
        searchPanel.add(endDateField);

        // Exam Type checkboxes
        bloodCheckBox = createExamCheckBox("Blood");
        cardiovascularCheckBox = createExamCheckBox("Cardiovascular");
        gastrointestinalCheckBox = createExamCheckBox("Gastrointestinal");
        respiratoryCheckBox = createExamCheckBox("Respiratory");
        ultrasoundCheckBox = createExamCheckBox("Ultrasound");
        xrayCheckBox = createExamCheckBox("X-Ray");
        ctScanCheckBox = createExamCheckBox("CT Scan");
        ecgCheckBox = createExamCheckBox("ECG");

        searchPanel.add(bloodCheckBox);
        searchPanel.add(cardiovascularCheckBox);
        searchPanel.add(gastrointestinalCheckBox);
        searchPanel.add(respiratoryCheckBox);
        searchPanel.add(ultrasoundCheckBox);
        searchPanel.add(xrayCheckBox);
        searchPanel.add(ctScanCheckBox);
        searchPanel.add(ecgCheckBox);

        abnormalResultsCheckBox = new JCheckBox("Only show abnormal results");
        abnormalResultsCheckBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        searchPanel.add(abnormalResultsCheckBox);

        // Activity Type checkboxes
        activityTypeCheckBox1 = createActivityCheckBox("Food Intake");
        activityTypeCheckBox2 = createActivityCheckBox("Rest Quality");
        activityTypeCheckBox3 = createActivityCheckBox("Emotion");
        activityTypeCheckBox4 = createActivityCheckBox("Medication");
        searchPanel.add(activityTypeCheckBox1);
        searchPanel.add(activityTypeCheckBox2);
        searchPanel.add(activityTypeCheckBox3);
        searchPanel.add(activityTypeCheckBox4);

        centerPanel.add(searchPanel);
        add(centerPanel, BorderLayout.CENTER);

        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, searchFontSize));
        searchButton.addActionListener(e -> searchRecords());
        searchPanel.add(searchButton);

        searchTypeComboBox.addActionListener(e -> toggleSearchField());
    }

    private JCheckBox createExamCheckBox(String label) {
        JCheckBox checkBox = new JCheckBox(label);
        checkBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        checkBox.setVisible(false);
        return checkBox;
    }

    private JCheckBox createActivityCheckBox(String label) {
        JCheckBox checkBox = new JCheckBox(label);
        checkBox.setFont(new Font("Tahoma", Font.PLAIN, searchFontSize));
        checkBox.setVisible(false);
        return checkBox;
    }

    private void setupExamSearch() {
        searchTypeComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Exam Type", "Date"}));
        abnormalResultsCheckBox.setVisible(true);
        toggleSearchField();
        revalidate();
        repaint();
    }

    private void setupActivitySearch() {
        searchTypeComboBox.setModel(new DefaultComboBoxModel<>(new String[]{"Activity Type", "Date"}));
        abnormalResultsCheckBox.setVisible(false);
        toggleSearchField();
        revalidate();
        repaint();
    }

    private void toggleSearchField() {
        String selectedType = (String) searchTypeComboBox.getSelectedItem();
        
        if ("Date".equals(selectedType)) {
            searchField.setVisible(false);
            startDateField.setVisible(true);
            endDateField.setVisible(true);
            toLabel.setVisible(true);
            setExamCheckBoxesVisible(false);
            setActivityCheckBoxesVisible(false);
        } else if ("Exam Type".equals(selectedType)) {
            searchField.setVisible(false);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            setExamCheckBoxesVisible(true);
            setActivityCheckBoxesVisible(false);
        } else if ("Activity Type".equals(selectedType)) {
            searchField.setVisible(false);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            setExamCheckBoxesVisible(false);
            setActivityCheckBoxesVisible(true);
        } else {
            searchField.setVisible(true);
            startDateField.setVisible(false);
            endDateField.setVisible(false);
            toLabel.setVisible(false);
            setExamCheckBoxesVisible(false);
            setActivityCheckBoxesVisible(false);
        }

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void setExamCheckBoxesVisible(boolean visible) {
        bloodCheckBox.setVisible(visible);
        cardiovascularCheckBox.setVisible(visible);
        gastrointestinalCheckBox.setVisible(visible);
        respiratoryCheckBox.setVisible(visible);
        ultrasoundCheckBox.setVisible(visible);
        xrayCheckBox.setVisible(visible);
        ctScanCheckBox.setVisible(visible);
        ecgCheckBox.setVisible(visible);
    }

    private void setActivityCheckBoxesVisible(boolean visible) {
        activityTypeCheckBox1.setVisible(visible);
        activityTypeCheckBox2.setVisible(visible);
        activityTypeCheckBox3.setVisible(visible);
        activityTypeCheckBox4.setVisible(visible);
        
    }

    private void searchRecords() {
        // TODO: connect to backend function
    }

    private void goBack() {
        mainFrame.showPreviousPage();
    }

    private void goHome() {
        mainFrame.showHomePage();
    }

    private void logout() {
        mainFrame.logout();
    }
}
