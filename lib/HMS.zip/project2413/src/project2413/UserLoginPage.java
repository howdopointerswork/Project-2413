package cscorner;

import javax.swing.*;
import java.awt.*;

public class UserLoginPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField textField;
    private JPasswordField passwordField;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                UserLoginPage frame = new UserLoginPage();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public UserLoginPage() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 800); // Set initial size, will be maximized
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize the frame while keeping the title bar
        setLocationRelativeTo(null); // Center the frame on the screen
        setResizable(true);

        Font largeFont = new Font("Tahoma", Font.PLAIN, 24);

        JPanel contentPane = new JPanel();
        contentPane.setLayout(new GridBagLayout());
        setContentPane(contentPane);

        JLabel lblNewLabel_2 = new JLabel("Personal Health Monitoring System");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 28));
        GridBagConstraints gbcTitle = new GridBagConstraints();
        gbcTitle.insets = new Insets(10, 10, 10, 10);
        gbcTitle.gridx = 0;
        gbcTitle.gridy = 0;
        gbcTitle.gridwidth = 3;
        gbcTitle.anchor = GridBagConstraints.CENTER;
        contentPane.add(lblNewLabel_2, gbcTitle);

        GridBagConstraints gbcUsernameLabel = new GridBagConstraints();
        gbcUsernameLabel.insets = new Insets(10, 10, 10, 10);
        gbcUsernameLabel.gridx = 0;
        gbcUsernameLabel.gridy = 5;
        gbcUsernameLabel.anchor = GridBagConstraints.EAST;
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(largeFont);
        contentPane.add(usernameLabel, gbcUsernameLabel);

        GridBagConstraints gbcTextField = new GridBagConstraints();
        gbcTextField.insets = new Insets(10, 10, 10, 10);
        gbcTextField.gridx = 2;
        gbcTextField.gridy = 5;
        textField = new JTextField(15);
        textField.setFont(largeFont);
        contentPane.add(textField, gbcTextField);

        GridBagConstraints gbcPasswordLabel = new GridBagConstraints();
        gbcPasswordLabel.insets = new Insets(10, 10, 10, 10);
        gbcPasswordLabel.gridx = 0;
        gbcPasswordLabel.gridy = 6;
        gbcPasswordLabel.anchor = GridBagConstraints.EAST;
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(largeFont);
        contentPane.add(passwordLabel, gbcPasswordLabel);

        GridBagConstraints gbcPasswordField = new GridBagConstraints();
        gbcPasswordField.insets = new Insets(10, 10, 10, 10);
        gbcPasswordField.gridx = 2;
        gbcPasswordField.gridy = 6;
        passwordField = new JPasswordField(15);
        passwordField.setFont(largeFont);
        contentPane.add(passwordField, gbcPasswordField);

        GridBagConstraints gbcLoginButton = new GridBagConstraints();
        gbcLoginButton.insets = new Insets(10, 10, 10, 10);
        gbcLoginButton.gridx = 2;
        gbcLoginButton.gridy = 7;
        gbcLoginButton.anchor = GridBagConstraints.WEST;
        JButton btnNewButton = new JButton("Log In");
        btnNewButton.setFont(largeFont);
        contentPane.add(btnNewButton, gbcLoginButton);

        // TODO - link to db.  For now we can test this by entering "username" and "password"
        btnNewButton.addActionListener(e -> {
            String username = textField.getText();
            String password = new String(passwordField.getPassword());

            if ("admin".equals(username) && "password".equals(password)) {
                UserHomePage userHomePage = new UserHomePage();
                userHomePage.setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password", "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        GridBagConstraints gbcRegPrompt = new GridBagConstraints();
        gbcRegPrompt.insets = new Insets(10, 10, 10, 10);
        gbcRegPrompt.gridx = 0;
        gbcRegPrompt.gridy = 8;
        gbcRegPrompt.anchor = GridBagConstraints.EAST;
        JLabel lblNewLabel_5 = new JLabel("No Account Yet?");
        lblNewLabel_5.setFont(largeFont);
        contentPane.add(lblNewLabel_5, gbcRegPrompt);

        GridBagConstraints gbcRegisterButton = new GridBagConstraints();
        gbcRegisterButton.insets = new Insets(10, 10, 10, 10);
        gbcRegisterButton.gridx = 2;
        gbcRegisterButton.gridy = 8;
        gbcRegisterButton.anchor = GridBagConstraints.WEST;
        JButton btnNewButton_1 = new JButton("Register");
        btnNewButton_1.setFont(largeFont);
        contentPane.add(btnNewButton_1, gbcRegisterButton);
    }
}