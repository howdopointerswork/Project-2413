package project2413;


public class RespiratoryTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	RespiratoryTest(String date, int id){
		
		super(date, id);
		
	}
	

	public void enterResults(double fvc, double fev1, double pio2) {
		
		
		
	}
	
}