package project2413;


public class RespiratoryTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	RespiratoryTest(String date, int id, String category, int status, int User_ID){
		
		super(date, id, "Respiratory", status, User_ID);
		
	}
	

	/*public void enterResults(double fvc, double fev1, double pio2) {
		
		
		
	}*/
	
}