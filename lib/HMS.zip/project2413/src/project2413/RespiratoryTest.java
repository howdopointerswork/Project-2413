package project2413;


public class RespiratoryTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	RespiratoryTest(String date, String category, int id){
		
		super(date, category, id);
		
	}
	

	public void enterResults(double fvc, double fev1, double pio2) {
		
		
		
	}
	
}