package cscorner;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class LogActivities extends JPanel {
    private static final long serialVersionUID = 1L;
    private JPanel centerPanel;
    private JTextField dateField;
    private Map<String, JSlider> activitySliders;
    private Map<String, JCheckBox> activityCheckboxes;
    private JButton submitButton;

    private MainFrame mainFrame;

    public LogActivities(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());

        // Top panel with back, home, and logout buttons
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.addActionListener(e -> mainFrame.showPreviousPage());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(buttonFont);
        homeButton.addActionListener(e -> mainFrame.showPage("Home"));

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(buttonFont);
        logoutButton.addActionListener(e -> mainFrame.showPage("Login"));

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // Center panel for date entry and activity sliders with checkboxes
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        // Date input field
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel dateLabel = new JLabel("Enter date (YYYY-MM-DD):");
        dateLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
        dateField = new JTextField(10);
        dateField.setFont(new Font("Tahoma", Font.PLAIN, 28));
        datePanel.add(dateLabel);
        datePanel.add(dateField);
        centerPanel.add(datePanel);

        // Initialize activity sliders and checkboxes
        activitySliders = new HashMap<>();
        activityCheckboxes = new HashMap<>();
        String[] activities = {"Food Intake", "Rest Quality", "Emotion", "Medication"};

        for (String activity : activities) {
            JPanel activityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            
            JCheckBox checkBox = new JCheckBox(activity);
            checkBox.setFont(new Font("Tahoma", Font.PLAIN, 28)); 
            checkBox.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            activityCheckboxes.put(activity, checkBox);

            JSlider slider = new JSlider(1, 10);
            slider.setMajorTickSpacing(1);
            slider.setPaintTicks(true);
            slider.setPaintLabels(true);
            slider.setFont(new Font("Tahoma", Font.PLAIN, 18));
            activitySliders.put(activity, slider);

            activityPanel.add(checkBox);
            activityPanel.add(slider);
            centerPanel.add(activityPanel);
        }

        // Submit button
        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Tahoma", Font.BOLD, 24));
        submitButton.addActionListener(e -> handleSubmit());
        centerPanel.add(submitButton);

        add(centerPanel, BorderLayout.CENTER);
    }

    private void handleSubmit() {
        String date = dateField.getText();

        if (date.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "Please enter a date.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        StringBuilder message = new StringBuilder("Activity Log\nDate: " + date + "\n\n");

        boolean atLeastOneSelected = false;
        for (Map.Entry<String, JCheckBox> entry : activityCheckboxes.entrySet()) {
            String activity = entry.getKey();
            JCheckBox checkBox = entry.getValue();
            
            // Check if the activity is selected
            if (checkBox.isSelected()) {
                atLeastOneSelected = true;
                int score = activitySliders.get(activity).getValue();
                message.append(activity).append(": ").append(score).append("\n");
            }
        }

        if (!atLeastOneSelected) {
            JOptionPane.showMessageDialog(mainFrame, "Please select at least one activity to log.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(mainFrame, message.toString(), "Submission Successful", JOptionPane.INFORMATION_MESSAGE);

        // Reset fields after submission
        dateField.setText("");
        for (JSlider slider : activitySliders.values()) {
            slider.setValue(1); // Reset sliders to minimum value
        }
        for (JCheckBox checkBox : activityCheckboxes.values()) {
            checkBox.setSelected(false); // Uncheck all checkboxes
        }
    }
}
