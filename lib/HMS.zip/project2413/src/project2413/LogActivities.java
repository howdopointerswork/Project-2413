package cscorner;

import javax.swing.*;
import java.awt.*;

public class LogActivities extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel centerPanel;  //' for submenus

    public LogActivities() {
        setTitle("Log Activities");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 800);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        // Set up content pane
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        // Top panel with back, home, and logout buttons
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.addActionListener(e -> goBack());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(buttonFont);
        homeButton.addActionListener(e -> goHome());

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(buttonFont);
        logoutButton.addActionListener(e -> logout());

        // Add buttons to panel
        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        contentPane.add(topPanel, BorderLayout.NORTH);

        // Center panel placeholder (to be updated dynamically)
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        JTextArea welcomeTextArea = new JTextArea("Select a main category to see subcategories.");
        welcomeTextArea.setFont(new Font("Tahoma", Font.PLAIN, 24));
        welcomeTextArea.setEditable(false);
        welcomeTextArea.setLineWrap(true);
        welcomeTextArea.setWrapStyleWord(true);
        welcomeTextArea.setOpaque(false);
        welcomeTextArea.setPreferredSize(new Dimension(800, 100));
        welcomeTextArea.setBorder(BorderFactory.createEmptyBorder(50, 40, 0, 0));
        centerPanel.add(welcomeTextArea);
        contentPane.add(centerPanel, BorderLayout.CENTER);

        // Left menu with main categories
        JPanel leftMenuPanel = new JPanel();
        leftMenuPanel.setLayout(new BorderLayout());
        leftMenuPanel.setPreferredSize(new Dimension(200, 0));

        JLabel menuLabel = new JLabel("ACTIVITIES", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
        leftMenuPanel.add(menuLabel, BorderLayout.NORTH);

        JPanel menuButtonsPanel = new JPanel();
        menuButtonsPanel.setLayout(new GridLayout(4, 1, 10, 10));

        // Example main categories with submenus
        JButton physicalActivitiesButton = new JButton("Physical");
        physicalActivitiesButton.setFont(buttonFont);
        physicalActivitiesButton.addActionListener(e -> showSubmenu("Physical Activities"));

        JButton mentalWellnessButton = new JButton("Mental Wellness");
        mentalWellnessButton.setFont(buttonFont);
        mentalWellnessButton.addActionListener(e -> showSubmenu("Mental Wellness"));

        JButton dietaryHabitsButton = new JButton("Dietary Habits");
        dietaryHabitsButton.setFont(buttonFont);
        dietaryHabitsButton.addActionListener(e -> showSubmenu("Dietary Habits"));

        JButton sleepPatternsButton = new JButton("Sleep Patterns");
        sleepPatternsButton.setFont(buttonFont);
        sleepPatternsButton.addActionListener(e -> showSubmenu("Sleep Patterns"));

        menuButtonsPanel.add(physicalActivitiesButton);
        menuButtonsPanel.add(mentalWellnessButton);
        menuButtonsPanel.add(dietaryHabitsButton);
        menuButtonsPanel.add(sleepPatternsButton);

        leftMenuPanel.add(menuButtonsPanel, BorderLayout.CENTER);
        contentPane.add(leftMenuPanel, BorderLayout.WEST);
    }

    // Method to show subcategory menu items in the center panel
    private void showSubmenu(String category) {
        centerPanel.removeAll();  // Clear existing content

        JLabel title = new JLabel("Subcategories for " + category);
        title.setFont(new Font("Tahoma", Font.BOLD, 24));
        centerPanel.add(title);

        // Example subcategory buttons for each category
        JButton sub1 = new JButton(category + " - Subcategory 1");
        sub1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        JButton sub2 = new JButton(category + " - Subcategory 2");
        sub2.setFont(new Font("Tahoma", Font.PLAIN, 20));

        centerPanel.add(sub1);
        centerPanel.add(sub2);

        // Refresh center panel to display new content
        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void goBack() {
        if (!UserHomePage.pageHistory.isEmpty()) {
            JFrame previousPage = UserHomePage.pageHistory.pop();
            previousPage.setVisible(true);
            dispose();
        } else {
            showCustomMessage("No previous page.");
        }
    }

    private void goHome() {
        UserHomePage.pageHistory.clear();
        new UserHomePage().setVisible(true);
        dispose();
    }

    private void logout() {
        UserHomePage.pageHistory.clear();
        new UserLoginPage().setVisible(true);
        dispose();
    }

    private void showCustomMessage(String message) {
        JLabel messageLabel = new JLabel(message);
        messageLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        JOptionPane.showMessageDialog(this, messageLabel, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogActivities frame = new LogActivities();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
