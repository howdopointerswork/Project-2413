package cscorner;

import javax.swing.*;
import java.awt.*;

public class LogActivities extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel centerPanel;  //' for submenus

    public LogActivities() {
     
    }
}
  

   