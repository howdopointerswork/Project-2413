package project2413;


public class BloodTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	BloodTest(String date, String category, int id){
		
		super(date, category, id);
		
	}
	
	
	public void enterResults(String bloodTestType, String testResult) {
		
		return;
		
	}
	
}