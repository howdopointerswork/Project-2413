package project2413;


public class BloodTest extends Exam{
	
	
	public int parentExamID;
	
	private String category;
	
	
	
	BloodTest(String date, int id, String category, int status, int User_ID){
		
		super(date, id, "Blood", status, User_ID);
		
	
		
	}
	
	
	/*public void enterResults(String bloodTestType, String testResult) {
		
		return;
		
	}*/
	
}