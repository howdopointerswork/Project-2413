package project2413;


public class BloodTest extends Exam{
	
	
	public int parentExamID;
	
	private String category;
	
	
	
	BloodTest(String date, String category, int status, int User_ID){
		
		super(date, 1, category, status, User_ID);
		
	
		
	}
	
	
	/*public void enterResults(String bloodTestType, String testResult) {
		
		return;
		
	}*/
	
}