package project2413;


public class GUI{
	
	//window builder stuff goes here
	
	
	private int width;
	
	private int height;
	
	GUI(int w, int h){
		
		this.width = w;
		
		this.height = h;
		
	}
	
	
	public void newWindow() {
		
		
	}
	
	
	public void clearScreen() {
		
		
		
	}
	
	
	public String getUsernameField() {
		
		
		return "";
	}
	
	
	public String getPasswordField() {
		
		return "";
	}
	
	
	
}