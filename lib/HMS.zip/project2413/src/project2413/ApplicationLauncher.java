package cscorner;

import javax.swing.*;

public class ApplicationLauncher {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            try {

                MainFrame mainFrame = new MainFrame();
                mainFrame.setVisible(true); // Show the main frame
            } catch (Exception e) {
                e.printStackTrace(); 
            }
        });
    }
}