package cscorner;

import javax.swing.*;
import java.awt.*;

public class LogExam extends JFrame {

    private static final long serialVersionUID = 1L;

    public LogExam() {
        setTitle("Log Exam Result");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 800);
        setLocationRelativeTo(null);

        // Set up content pane
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        // Top panel with back, home, and logout buttons
        JPanel topPanel = new JPanel(new BorderLayout());
       
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5)); // Align to the right with spacing

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 20);
        
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        backButton.addActionListener(e -> goBack()); // Define the back functionality

        JButton homeButton = new JButton("Home");
        homeButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        homeButton.addActionListener(e -> goHome()); // Define the home functionality

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        logoutButton.addActionListener(e -> logout()); // Define the logout functionality

        // Back / Home / Logout added to panel
        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);

        topPanel.add(buttonPanel, BorderLayout.EAST);
        contentPane.add(topPanel, BorderLayout.NORTH);
        
        // Create a panel to hold the welcome text area and the form panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS)); // Use BoxLayout to stack components

        // Welcome message & brief description of program functions
        JTextArea welcomeTextArea = new JTextArea("Here you can enter results "
        		+ "from medical examinations. The health monitoring system "
        		+ "will notify you if you have abnormal results for "
        		+ "three consecutive tests. To get started, select "
        		+ "a category from the left menu.");
        welcomeTextArea.setFont(new Font("Tahoma", Font.PLAIN, 24));
        welcomeTextArea.setEditable(false); 
        welcomeTextArea.setLineWrap(true);  
        welcomeTextArea.setWrapStyleWord(true); 
        welcomeTextArea.setOpaque(false); 
        
        welcomeTextArea.setPreferredSize(new Dimension(800, 100)); 
        welcomeTextArea.setBorder(BorderFactory.createEmptyBorder(50, 40, 0, 0)); // Padding for the welcome message
        
        // Add welcomeTextArea to centerPanel
        centerPanel.add(welcomeTextArea);
        
        // Create the form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Add the formPanel to centerPanel
        centerPanel.add(formPanel);
        
        // Add the centerPanel to the content pane
        contentPane.add(centerPanel, BorderLayout.CENTER);

        // Defining left menu
        JPanel leftMenuPanel = new JPanel();
        leftMenuPanel.setLayout(new BorderLayout());
        leftMenuPanel.setPreferredSize(new Dimension(200, 0));

        // MENU
        JLabel menuLabel = new JLabel("EXAM", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
        leftMenuPanel.add(menuLabel, BorderLayout.NORTH);

        // Panel for menu buttons
        JPanel menuButtonsPanel = new JPanel();
        menuButtonsPanel.setLayout(new GridLayout(4, 1, 10, 10)); // 4 rows for 4 buttons

        // Buttons for each test type
        JButton bloodTestButton = new JButton("Blood");
        bloodTestButton.setFont(buttonFont);
        JButton cardiovascularTestButton = new JButton("Cardiovascular");
        cardiovascularTestButton.setFont(buttonFont);
        JButton gastrointestinalTestButton = new JButton("Gastrointestinal");
        gastrointestinalTestButton.setFont(buttonFont);
        JButton respiratoryTestButton = new JButton("Respiratory");
        respiratoryTestButton.setFont(buttonFont);

        // Add the components to panel 
        menuButtonsPanel.add(bloodTestButton);
        menuButtonsPanel.add(cardiovascularTestButton);
        menuButtonsPanel.add(gastrointestinalTestButton);
        menuButtonsPanel.add(respiratoryTestButton);

        leftMenuPanel.add(menuButtonsPanel, BorderLayout.CENTER);
        contentPane.add(leftMenuPanel, BorderLayout.WEST);
    }

    private void goBack() {
        // TODO: find way to implement back button
        showCustomMessage("Back button clicked.");
    }

    private void goHome() {
    	dispose();
        new UserHomePage().setVisible(true); 
    }

    private void showCustomMessage(String message) {
        JLabel messageLabel = new JLabel(message);
        messageLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        JOptionPane.showMessageDialog(this, messageLabel, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    private void logout() {
        dispose();
        new UserLoginPage().setVisible(true); 
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogExam frame = new LogExam();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
