package cscorner;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LogExam extends JPanel {
    private static final long serialVersionUID = 1L;
    private JPanel centerPanel;
    private Map<String, List<String>> subcategories;
    private String currentSubcategory;
    private int defaultExamFont = 26;

    // Input fields for date and test result
    private JTextField dateField;
    private JTextField resultField;
    private JButton submitButton;

    private MainFrame mainFrame;

    public LogExam(MainFrame mainFrame) {
        this.mainFrame = mainFrame;

        setLayout(new BorderLayout());

        // Set up subcategories
        initializeSubcategories();

        // Top panel with back, home, and logout buttons
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.addActionListener(e -> mainFrame.showPreviousPage());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(buttonFont);
        homeButton.addActionListener(e -> mainFrame.showPage("Home"));

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(buttonFont);
        logoutButton.addActionListener(e -> mainFrame.showPage("Login"));

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // Center panel placeholder (for updating dynamically)
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        JTextArea welcomeTextArea = new JTextArea("Here, you can enter results "
                + "from your medical examinations. Select a category from the left menu "
                + "to see subcategories. \n\n"
                + "When prompted for a test result value, enter only the numeric "
                + "value of your test result without the unit of measurement. For blood pressure, "
                + "enter in format of number/number.");
        welcomeTextArea.setFont(new Font("Tahoma", Font.PLAIN, defaultExamFont));
        welcomeTextArea.setEditable(false);
        welcomeTextArea.setLineWrap(true);
        welcomeTextArea.setWrapStyleWord(true);
        welcomeTextArea.setOpaque(false);
        welcomeTextArea.setBorder(BorderFactory.createEmptyBorder(50, 40, 0, 0));
        centerPanel.add(welcomeTextArea);
        add(centerPanel, BorderLayout.CENTER);

        // Left menu with main categories
        JPanel leftMenuPanel = new JPanel();
        leftMenuPanel.setLayout(new BorderLayout());
        leftMenuPanel.setPreferredSize(new Dimension(200, 0));

        JLabel menuLabel = new JLabel("EXAM", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
        leftMenuPanel.add(menuLabel, BorderLayout.NORTH);

        JPanel menuButtonsPanel = new JPanel();
        menuButtonsPanel.setLayout(new GridLayout(8, 1, 10, 10));

        JButton bloodTestButton = new JButton("Blood");
        bloodTestButton.setFont(buttonFont);
        bloodTestButton.addActionListener(e -> showSubmenu("Blood"));

        JButton cardiovascularTestButton = new JButton("Cardiovascular");
        cardiovascularTestButton.setFont(buttonFont);
        cardiovascularTestButton.addActionListener(e -> showSubmenu("Cardiovascular"));

        JButton gastrointestinalTestButton = new JButton("Gastrointestinal");
        gastrointestinalTestButton.setFont(buttonFont);
        gastrointestinalTestButton.addActionListener(e -> showSubmenu("Gastrointestinal"));

        JButton respiratoryTestButton = new JButton("Respiratory");
        respiratoryTestButton.setFont(buttonFont);
        respiratoryTestButton.addActionListener(e -> showSubmenu("Respiratory"));
        
        JButton ultrasoundTestButton = new JButton("Ultrasound");
        ultrasoundTestButton.setFont(buttonFont);
        ultrasoundTestButton.addActionListener(e -> showSubmenu("Ultrasound"));
        
        JButton xRayTestButton = new JButton("X-Ray");
        xRayTestButton.setFont(buttonFont);
        xRayTestButton.addActionListener(e -> showSubmenu("X-Ray"));
        
        JButton ctScanTestButton = new JButton("CT Scan");
        ctScanTestButton.setFont(buttonFont);
        ctScanTestButton.addActionListener(e -> showSubmenu("CT Scan"));
        
        JButton ecgTestButton = new JButton("ECG");
        ecgTestButton.setFont(buttonFont);
        ecgTestButton.addActionListener(e -> showSubmenu("ECG"));


        menuButtonsPanel.add(bloodTestButton);
        menuButtonsPanel.add(cardiovascularTestButton);
        menuButtonsPanel.add(gastrointestinalTestButton);
        menuButtonsPanel.add(respiratoryTestButton);
        menuButtonsPanel.add(ultrasoundTestButton);
        menuButtonsPanel.add(xRayTestButton);
        menuButtonsPanel.add(ctScanTestButton);
        menuButtonsPanel.add(ecgTestButton);


        leftMenuPanel.add(menuButtonsPanel, BorderLayout.CENTER);
        add(leftMenuPanel, BorderLayout.WEST);
    }

    // Initialize subcategories for each main category
    private void initializeSubcategories() {
        subcategories = new HashMap<>();
        subcategories.put("Blood", Arrays.asList("Glucose Test", "Calcium Test", "Sodium Test"));
        subcategories.put("Cardiovascular", Arrays.asList("Blood Pressure Test", "Heart Rate Test"));
        subcategories.put("Gastrointestinal", Arrays.asList("pH Urine Test", "Stool Test", "Liver Enzymes Test"));
        subcategories.put("Respiratory", Arrays.asList("Lung Capacity Test", "Rate of Flow Test"));
    }

    // Method to display submenu items in the center panel
    private void showSubmenu(String category) {
        centerPanel.removeAll(); // Clear previous components

        JLabel title = new JLabel(category + " Tests");
        title.setFont(new Font("Tahoma", Font.BOLD, defaultExamFont));
        centerPanel.add(title);

        List<String> subcategoryList = subcategories.getOrDefault(category, Collections.emptyList());
        for (String subcategory : subcategoryList) {
            JButton subButton = new JButton(subcategory);
            subButton.setFont(new Font("Tahoma", Font.PLAIN, defaultExamFont));
            subButton.addActionListener(e -> handleSubcategoryClick(subcategory)); // Handle subcategory click
            centerPanel.add(subButton);
        }

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void handleSubcategoryClick(String subcategory) {
        currentSubcategory = subcategory; // Store the current subcategory
        centerPanel.removeAll();

        JLabel title = new JLabel("Log Result for: " + subcategory);
        title.setFont(new Font("Tahoma", Font.BOLD, defaultExamFont));
        centerPanel.add(title);

        // Input fields for date and test result
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        Font textFieldFont = new Font("Tahoma", Font.PLAIN, defaultExamFont);

        dateField = new JTextField(6);
        dateField.setFont(textFieldFont);

        resultField = new JTextField(6);
        resultField.setFont(textFieldFont);

        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Tahoma", Font.BOLD, defaultExamFont));
        submitButton.addActionListener(e -> handleSubmit(subcategory));

        Font labelFont = new Font("Tahoma", Font.PLAIN, defaultExamFont);

        JLabel dateLabel = new JLabel("Enter date (YYYY-MM-DD):");
        dateLabel.setFont(labelFont);
        inputPanel.add(dateLabel);
        inputPanel.add(dateField);

        JLabel resultLabel = new JLabel("Enter test result:");
        resultLabel.setFont(labelFont);
        inputPanel.add(resultLabel);
        inputPanel.add(resultField);

        inputPanel.add(submitButton);
        centerPanel.add(inputPanel);

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void handleSubmit(String subcategory) {
        String date = dateField.getText();
        String testResult = resultField.getText();

        if (date.isEmpty() || testResult.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "Please enter both date and test result.",
                                          "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String message = String.format("Subcategory: %s\nDate: %s\nTest Result: %s", subcategory, date, testResult);
        JOptionPane.showMessageDialog(mainFrame, message, "Submission Successful", JOptionPane.INFORMATION_MESSAGE);
        
        dateField.setText("");
        resultField.setText("");
    }
}
