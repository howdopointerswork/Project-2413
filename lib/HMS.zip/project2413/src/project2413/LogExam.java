package cscorner;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LogExam extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel centerPanel;
    private Map<String, List<String>> subcategories;
    private String currentSubcategory;
    private int defaultExamFont = 26;
    
    // Input fields for date and test result
    private JTextField dateField;
    private JTextField resultField;
    private JButton submitButton;

    public LogExam() {
        setTitle("Log Exam Result");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 800);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null);

        // Set up subcategories
        initializeSubcategories();

        // Set up content pane
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        // Top panel with back, home, and logout buttons
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        backButton.addActionListener(e -> goBack());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        homeButton.addActionListener(e -> goHome());

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
        logoutButton.addActionListener(e -> logout());

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        contentPane.add(topPanel, BorderLayout.NORTH);

        // Center panel placeholder (for updating dynamically)
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        JTextArea welcomeTextArea = new JTextArea("Here, you can enter results "
                + "from your medical examinations. Select a category from the left menu "
                + "to see subcategories. \n\n"
                + "When propmpted for a test result value, enter only the numeric "
                + "value of your test result without the unit of measurement. For blood pressure, "
                + "enter in format of number/number.");
        welcomeTextArea.setFont(new Font("Tahoma", Font.PLAIN, defaultExamFont));
        welcomeTextArea.setEditable(false);
        welcomeTextArea.setLineWrap(true);
        welcomeTextArea.setWrapStyleWord(true);
        welcomeTextArea.setOpaque(false);
        welcomeTextArea.setBorder(BorderFactory.createEmptyBorder(50, 40, 0, 0));
        centerPanel.add(welcomeTextArea);
        contentPane.add(centerPanel, BorderLayout.CENTER);

        // Left menu with main categories
        JPanel leftMenuPanel = new JPanel();
        leftMenuPanel.setLayout(new BorderLayout());
        leftMenuPanel.setPreferredSize(new Dimension(200, 0));

        JLabel menuLabel = new JLabel("EXAM", SwingConstants.CENTER);
        menuLabel.setFont(new Font("Tahoma", Font.BOLD, 36));
        leftMenuPanel.add(menuLabel, BorderLayout.NORTH);

        JPanel menuButtonsPanel = new JPanel();
        menuButtonsPanel.setLayout(new GridLayout(4, 1, 10, 10));

        JButton bloodTestButton = new JButton("Blood");
        bloodTestButton.setFont(buttonFont);
        bloodTestButton.addActionListener(e -> showSubmenu("Blood"));

        JButton cardiovascularTestButton = new JButton("Cardiovascular");
        cardiovascularTestButton.setFont(buttonFont);
        cardiovascularTestButton.addActionListener(e -> showSubmenu("Cardiovascular"));

        JButton gastrointestinalTestButton = new JButton("Gastrointestinal");
        gastrointestinalTestButton.setFont(buttonFont);
        gastrointestinalTestButton.addActionListener(e -> showSubmenu("Gastrointestinal"));

        JButton respiratoryTestButton = new JButton("Respiratory");
        respiratoryTestButton.setFont(buttonFont);
        respiratoryTestButton.addActionListener(e -> showSubmenu("Respiratory"));

        menuButtonsPanel.add(bloodTestButton);
        menuButtonsPanel.add(cardiovascularTestButton);
        menuButtonsPanel.add(gastrointestinalTestButton);
        menuButtonsPanel.add(respiratoryTestButton);

        leftMenuPanel.add(menuButtonsPanel, BorderLayout.CENTER);
        contentPane.add(leftMenuPanel, BorderLayout.WEST);
    }

    // Initialize subcategories for each main category
    private void initializeSubcategories() {
        subcategories = new HashMap<>();
        subcategories.put("Blood", Arrays.asList("Glucose Test", "Calcium Test", "Sodium Test"));
        subcategories.put("Cardiovascular", Arrays.asList("Blood Pressure Test", "Heart Rate Test"));
        subcategories.put("Gastrointestinal", Arrays.asList("pH Urine Test", "Stool Test", "Liver Enzymes Test"));
        subcategories.put("Respiratory", Arrays.asList("Lung Capacity Test", "Rate of Flow Test"));
    }

    // Method to display submenu items in the center panel
    private void showSubmenu(String category) {
        centerPanel.removeAll(); // Clear previous components

        JLabel title = new JLabel(category + " Tests");
        title.setFont(new Font("Tahoma", Font.BOLD, defaultExamFont));
        centerPanel.add(title);

        List<String> subcategoryList = subcategories.getOrDefault(category, Collections.emptyList());
        for (String subcategory : subcategoryList) {
            JButton subButton = new JButton(subcategory);
            subButton.setFont(new Font("Tahoma", Font.PLAIN, defaultExamFont));
            subButton.addActionListener(e -> handleSubcategoryClick(subcategory)); // Handle subcategory click
            centerPanel.add(subButton);
        }

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private void handleSubcategoryClick(String subcategory) {
        currentSubcategory = subcategory; // Store the current subcategory
        centerPanel.removeAll();

        JLabel title = new JLabel("Log Result for: " + subcategory);
        title.setFont(new Font("Tahoma", Font.BOLD, defaultExamFont));
        centerPanel.add(title);

        // Create a panel to hold the input fields with FlowLayout
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0)); // Add padding (top, left, bottom, right)

        // Create a font for the text fields
        Font textFieldFont = new Font("Tahoma", Font.PLAIN, defaultExamFont); // Set the font name, style, and size

        // Create input fields for date and test result with larger sizes
        dateField = new JTextField(6); // Smaller date input
        dateField.setFont(textFieldFont); // Set font for date field

        resultField = new JTextField(6); // Smaller test result input
        resultField.setFont(textFieldFont); // Set font for result field

        submitButton = new JButton("Submit"); // Submit button
        submitButton.setFont(new Font("Tahoma", Font.BOLD, defaultExamFont));

        // Create a font for labels
        Font labelFont = new Font("Tahoma", Font.PLAIN, defaultExamFont); // Set the font name, style, and size

        // Add components to inputPanel with larger font for labels
        JLabel dateLabel = new JLabel("Enter date (YYYY-MM-DD):");
        dateLabel.setFont(labelFont); // Set the font for the date label
        inputPanel.add(dateLabel);
        inputPanel.add(dateField);

        JLabel resultLabel = new JLabel("Enter test result:");
        resultLabel.setFont(labelFont); // Set the font for the result label
        inputPanel.add(resultLabel);
        inputPanel.add(resultField);

        // Add submit button
        inputPanel.add(submitButton);

        // Add inputPanel to centerPanel
        centerPanel.add(inputPanel);

        centerPanel.revalidate();
        centerPanel.repaint();
    }


    private void handleSubmit(String subcategory) {
        String date = dateField.getText();
        String testResult = resultField.getText();

        // Validate inputs
        if (date.isEmpty() || testResult.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both date and test result.",
                                          "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Process the data (you can store it, log it, or whatever is appropriate)
        String message = String.format("Subcategory: %s\nDate: %s\nTest Result: %s", subcategory, date, testResult);
        JOptionPane.showMessageDialog(this, message, "Submission Successful", JOptionPane.INFORMATION_MESSAGE);
        
        // Optionally, clear fields after submission
        dateField.setText("");
        resultField.setText("");
    }

    private void goBack() {
        if (!UserHomePage.pageHistory.isEmpty()) {
            JFrame previousPage = UserHomePage.pageHistory.pop();
            previousPage.setVisible(true);
            dispose();
        } else {
            showCustomMessage("No previous page.");
        }
    }

    private void goHome() {
        UserHomePage.pageHistory.clear();
        new UserHomePage().setVisible(true);
        dispose();
    }

    private void logout() {
        UserHomePage.pageHistory.clear();
        new UserLoginPage().setVisible(true);
        dispose();
    }

    private void showCustomMessage(String message) {
        JLabel messageLabel = new JLabel(message);
        messageLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
        JOptionPane.showMessageDialog(this, messageLabel, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogExam frame = new LogExam();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
