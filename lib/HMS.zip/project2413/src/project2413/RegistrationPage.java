package project2413;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;

public class RegistrationPage extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField dobField;
    private JTextField weightField;
    private JTextField heightField;
    private JRadioButton maleRadio;
    private JRadioButton femaleRadio;
    private MainFrame mainFrame;

    public RegistrationPage(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new GridBagLayout());

        Font largeFont = new Font("Tahoma", Font.PLAIN, 24);

        // Title 
        JLabel lblTitle = new JLabel("Register New Account");
        lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 28));
        GridBagConstraints gbcTitle = new GridBagConstraints();
        gbcTitle.insets = new Insets(10, 10, 20, 10);
        gbcTitle.gridx = 0;
        gbcTitle.gridy = 0;
        gbcTitle.gridwidth = 2;
        gbcTitle.anchor = GridBagConstraints.CENTER;
        add(lblTitle, gbcTitle);

        // Username 
        createLabelAndField("Username:", largeFont, usernameField = new JTextField(15), 1);
        ((AbstractDocument) usernameField.getDocument()).setDocumentFilter(new LengthFilter(50));

        // Pssword
        createLabelAndField("Password:", largeFont, passwordField = new JPasswordField(15), 2);
        ((AbstractDocument) passwordField.getDocument()).setDocumentFilter(new LengthFilter(50));

        // fname
        createLabelAndField("First Name:", largeFont, firstNameField = new JTextField(15), 4);
        ((AbstractDocument) firstNameField.getDocument()).setDocumentFilter(new LengthFilter(25));

        // Lname 
        createLabelAndField("Last Name:", largeFont, lastNameField = new JTextField(15), 5);
        ((AbstractDocument) lastNameField.getDocument()).setDocumentFilter(new LengthFilter(25));

        // dob
        createLabelAndField("Date of Birth (YYYY-MM-DD):", largeFont, dobField = new JTextField(10), 6);

        // gender radio
        JLabel sexLabel = new JLabel("Sex:");
        sexLabel.setFont(largeFont);
        GridBagConstraints gbcSexLabel = new GridBagConstraints();
        gbcSexLabel.insets = new Insets(10, 10, 10, 10);
        gbcSexLabel.gridx = 0;
        gbcSexLabel.gridy = 7;
        gbcSexLabel.anchor = GridBagConstraints.EAST;
        add(sexLabel, gbcSexLabel);

        maleRadio = new JRadioButton("M");
        femaleRadio = new JRadioButton("F");
        maleRadio.setFont(largeFont);
        femaleRadio.setFont(largeFont);
        ButtonGroup sexGroup = new ButtonGroup();
        sexGroup.add(maleRadio);
        sexGroup.add(femaleRadio);

        JPanel sexPanel = new JPanel();
        sexPanel.add(maleRadio);
        sexPanel.add(femaleRadio);

        GridBagConstraints gbcSexPanel = new GridBagConstraints();
        gbcSexPanel.insets = new Insets(10, 10, 10, 10);
        gbcSexPanel.gridx = 1;
        gbcSexPanel.gridy = 7;
        add(sexPanel, gbcSexPanel);

        // Weight Field
        createLabelAndField("Weight (kg):", largeFont, weightField = new JTextField(10), 8);

        // Height Field
        createLabelAndField("Height (m):", largeFont, heightField = new JTextField(10), 9);

        // Register Button
        JButton registerButton = new JButton("Register");
        registerButton.setFont(largeFont);
        GridBagConstraints gbcRegisterButton = new GridBagConstraints();
        gbcRegisterButton.insets = new Insets(20, 10, 10, 10);
        gbcRegisterButton.gridx = 1;
        gbcRegisterButton.gridy = 10;
        gbcRegisterButton.anchor = GridBagConstraints.WEST;
        add(registerButton, gbcRegisterButton);

        // Register button action listener
        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String dob = dobField.getText();
            String weight = weightField.getText();
            String height = heightField.getText();
            String sex = maleRadio.isSelected() ? "M" : femaleRadio.isSelected() ? "F" : "";
            
   
            
            if (username.isEmpty() || password.isEmpty() || dob.isEmpty() || sex.isEmpty() || weight.isEmpty() || height.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required", "Registration Error", JOptionPane.ERROR_MESSAGE);
            } else {
            	Float w = Float.parseFloat(weight);
        		Float h = Float.parseFloat(height);
        	
            	//add user info here
        		System.out.println(dob);
            	mainFrame.hs.signUp(username, password, username, username, dob, sex, w, h, mainFrame.mon);
                JOptionPane.showMessageDialog(this, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                mainFrame.showPage("Login"); // Return to login 
            }
        });

        // back button
        JButton backButton = new JButton("Back");
        backButton.setFont(largeFont);
        GridBagConstraints gbcBackButton = new GridBagConstraints();
        gbcBackButton.insets = new Insets(20, 10, 10, 10);
        gbcBackButton.gridx = 0;
        gbcBackButton.gridy = 10;
        gbcBackButton.anchor = GridBagConstraints.EAST;
        add(backButton, gbcBackButton);

        // back button action listener
        backButton.addActionListener(e -> mainFrame.showPage("Login"));
    }

    private void createLabelAndField(String labelText, Font font, JTextField textField, int yPos) {
        JLabel label = new JLabel(labelText);
        label.setFont(font);
        GridBagConstraints gbcLabel = new GridBagConstraints();
        gbcLabel.insets = new Insets(10, 10, 10, 10);
        gbcLabel.gridx = 0;
        gbcLabel.gridy = yPos;
        gbcLabel.anchor = GridBagConstraints.EAST;
        add(label, gbcLabel);

        textField.setFont(font);
        GridBagConstraints gbcField = new GridBagConstraints();
        gbcField.insets = new Insets(10, 10, 10, 10);
        gbcField.gridx = 1;
        gbcField.gridy = yPos;
        add(textField, gbcField);
    }
}
