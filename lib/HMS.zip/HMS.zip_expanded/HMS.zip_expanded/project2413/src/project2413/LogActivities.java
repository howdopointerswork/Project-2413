package project2413;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class LogActivities extends JPanel {
    private static final long serialVersionUID = 1L;
    private JPanel centerPanel;
    private JTextField dateField;
    private Map<String, JSlider> activitySliders;
    private Map<String, JCheckBox> activityCheckboxes;
    private Map<String, JTextField> activityComments;
    private JButton submitButton;

    private MainFrame mainFrame;

    public LogActivities(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());

        // Top panel with nav buttons
        JPanel topPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));

        Font buttonFont = new Font("Tahoma", Font.PLAIN, 24);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.addActionListener(e -> mainFrame.showPreviousPage());

        JButton homeButton = new JButton("Home");
        homeButton.setFont(buttonFont);
        homeButton.addActionListener(e -> mainFrame.showPage("Home"));

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(buttonFont);
        logoutButton.addActionListener(e -> mainFrame.showPage("Login"));

        buttonPanel.add(backButton);
        buttonPanel.add(homeButton);
        buttonPanel.add(logoutButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // Center panel 
        centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

     // Instructions button
        JButton instructionsButton = new JButton("Instructions");
        instructionsButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        instructionsButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(mainFrame,
                "<html><div style='text-align: left; font-size: 20px;'>Here you can log activity information if you have been prompted by the Health Monitoring System.<br>Entering your activity data will help the system provide you advice regarding health categories which are being monitored.<br><br>"
                + "Select the activities you wish to log, use the toggle to indicate the quality of your activity (1 is poor, 10 is excellent). Enter comment(s) and then press submit to log.</div></html>",
                "Instructions", JOptionPane.INFORMATION_MESSAGE);
        });

        // Add the Instructions button to the top left of the top panel
        topPanel.add(instructionsButton, BorderLayout.WEST);

        // date input
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel dateLabel = new JLabel("Enter date for which you are logging activity data (YYYY-MM-DD):");
        dateLabel.setFont(new Font("Tahoma", Font.PLAIN, 28));
        dateField = new JTextField(10);
        dateField.setFont(new Font("Tahoma", Font.PLAIN, 28));
        datePanel.add(dateLabel);
        datePanel.add(dateField);
        centerPanel.add(datePanel);

        // Initializing sliders ^& checkboxes 
        activitySliders = new HashMap<>();
        activityCheckboxes = new HashMap<>();
        String[] activities = {"Food Intake", "Rest Quality", "Emotion", "Medication"};

        for (String activity : activities) {
            JPanel activityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

            JCheckBox checkBox = new JCheckBox(activity);
            checkBox.setFont(new Font("Tahoma", Font.PLAIN, 28)); 
            checkBox.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            activityCheckboxes.put(activity, checkBox);

            JSlider slider = new JSlider(1, 10);
            slider.setMajorTickSpacing(1);
            slider.setPaintTicks(true);
            slider.setPaintLabels(true);
            slider.setFont(new Font("Tahoma", Font.PLAIN, 18));
            activitySliders.put(activity, slider);

            activityPanel.add(checkBox);
            activityPanel.add(slider);

            JTextField commentField = new JTextField(15);
            commentField.setFont(new Font("Tahoma", Font.PLAIN, 24));

            JLabel commentLabel = new JLabel("Comment: ");
            commentLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));

            activityPanel.add(commentLabel);
            activityPanel.add(commentField);

            centerPanel.add(activityPanel);
        }

        // Submit button
        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Tahoma", Font.BOLD, 24));
        submitButton.addActionListener(e -> handleSubmit());
        centerPanel.add(submitButton);

        // add center panel to main panel
        add(centerPanel, BorderLayout.CENTER);
    }


    private void handleSubmit() {
    	//todo: connect to backend function
        String date = dateField.getText();

        if (date.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "Please enter a date.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        StringBuilder message = new StringBuilder("Activity Log\nDate: " + date + "\n\n");

        boolean atLeastOneSelected = false;
        for (Map.Entry<String, JCheckBox> entry : activityCheckboxes.entrySet()) {
            String activity = entry.getKey();
            JCheckBox checkBox = entry.getValue();

            // validate user has selected at least 1 activity to submit 
            if (checkBox.isSelected()) {
                atLeastOneSelected = true;
                int score = activitySliders.get(activity).getValue();
                String comment = activityComments.get(activity).getText();
                
                message.append(activity).append(": ").append(score);
                if (!comment.isEmpty()) {
                    message.append(" | Comment: ").append(comment);
                }
                message.append("\n");
            }
        }

        if (!atLeastOneSelected) {
            JOptionPane.showMessageDialog(mainFrame, "Please select at least one activity to log.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(mainFrame, message.toString(), "Submission Successful", JOptionPane.INFORMATION_MESSAGE);

        // Reset fields after a user submits
        dateField.setText("");
        for (JSlider slider : activitySliders.values()) {
            slider.setValue(1); // reset sliders
        }
        for (JCheckBox checkBox : activityCheckboxes.values()) {
            checkBox.setSelected(false); // uncheck checkboxes
        }
        for (JTextField commentField : activityComments.values()) {
            commentField.setText(""); // clar comments 
        }
    }
}
