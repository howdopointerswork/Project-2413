package project2413;


public class RespiratoryTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	RespiratoryTest(String date, String category, int status, int User_ID){
		
		super(date, 4, category, status, User_ID);
		
	}
	

	/*public void enterResults(double fvc, double fev1, double pio2) {
		
		
		
	}*/
	
}