package project2413;


public class GastrointestinalTest extends Exam{
	
	
	public int parentExamID;
	
	
	
	GastrointestinalTest(String date, String category, int status, int User_ID){
		
		super(date, 3, category, status, User_ID);
		
	}
	

	/*public void enterResults(String stoolSampleType, String analysis) {
		
		
		
	}*/
	
}